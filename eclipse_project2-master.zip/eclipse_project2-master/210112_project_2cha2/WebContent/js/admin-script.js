
		$('.navMedicine').hover(function() {
		$('.subMenu').stop().show();
		$('.navMedicine>a').css('color', '#333');},
							function() {
		$('.subMenu').stop().hide();
		$('.navMedicine>a').css('color', '#777');}
						   );
