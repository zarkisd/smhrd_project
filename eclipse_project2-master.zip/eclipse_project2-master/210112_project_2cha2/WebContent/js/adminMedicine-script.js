


$('#tabMenu li:nth-of-type(1)').click(
	function() {
		$('#medicineAll').show();
		$('#vitamin').hide();
		$('#lutein').hide();
		$('#calcium').hide();
		$('#lacto').hide();
		$('#tabMenu li:nth-of-type(1) h2').css('background-color',
			'rgb(60,152,205)').css('color', 'white');
		$('a:link').css('text-decoration', 'none');
		$('#tabMenu li:nth-of-type(2) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(3) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(4) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(5) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		event.preventDefault ? event.preventDefault()
			: (event.returnValue = false);
	});


$('#tabMenu li:nth-of-type(2)').click(
	function() {

		$('#medicineAll').hide();
		$('#vitamin').show();
		$('#lutein').hide();
		$('#calcium').hide();
		$('#lacto').hide();

		$('#tabMenu li:nth-of-type(2) h2').css('background-color',
			'rgb(60,152,205)').css('color', 'white');
		$('a:link').css('text-decoration', 'none');
		$('#tabMenu li:nth-of-type(1) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(3) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(4) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(5) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		event.preventDefault ? event.preventDefault()
			: (event.returnValue = false);
	});

$('#tabMenu li:nth-of-type(3)').click(
	function() {
		$('#medicineAll').hide();
		$('#vitamin').hide();
		$('#lutein').show();
		$('#calcium').hide();
		$('#lacto').hide();
		$('#tabMenu li:nth-of-type(3) h2').css('background-color',
			'rgb(60,152,205)').css('color', 'white');
		$('a:link').css('text-decoration', 'none');
		$('#tabMenu li:nth-of-type(1) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(2) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(4) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(5) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		event.preventDefault ? event.preventDefault()
			: (event.returnValue = false);
	});

$('#tabMenu li:nth-of-type(4)').click(
	function() {
		$('#medicineAll').hide();
		$('#vitamin').hide();
		$('#lutein').hide();
		$('#calcium').show();
		$('#lacto').hide();
		$('#tabMenu li:nth-of-type(4) h2').css('background-color',
			'rgb(60,152,205)').css('color', 'white');
		$('a:link').css('text-decoration', 'none');
		$('#tabMenu li:nth-of-type(1) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(2) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(3) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(5) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		event.preventDefault ? event.preventDefault()
			: (event.returnValue = false);
	});

$('#tabMenu li:nth-of-type(5)').click(
	function() {
		$('#medicineAll').hide();
		$('#vitamin').hide();
		$('#lutein').hide();
		$('#calcium').hide();
		$('#lacto').show();
		$('#tabMenu li:nth-of-type(5) h2').css('background-color',
			'rgb(60,152,205)').css('color', 'white');
		$('a:link').css('text-decoration', 'none');
		$('#tabMenu li:nth-of-type(1) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(2) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(3) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		$('#tabMenu li:nth-of-type(4) h2').css('background-color',
			'#eee')
			.css('color', '#888');
		event.preventDefault ? event.preventDefault()
			: (event.returnValue = false);
	});