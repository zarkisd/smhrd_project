package eventDidMountCalendarModel;

public class MountVO {
	private String title;
    private String startDate;
    private String dayname;
    private String starttime;
    private int pillrecommend;
    private int pilltotal;
    private String pillexpire;
    private String icon;
    private String eachday;
    private String todate;
    private int doneday;
    
	public MountVO(String title, String startDate, String icon) {
		super();
		this.title = title;
		this.startDate = startDate;
		this.icon = icon;
	}
	
	public String getTodate() {
		return todate;
	}

	public void setTodate(String todate) {
		this.todate = todate;
	}

	public void setDoneday(int doneday) {
		this.doneday = doneday;
	}

	public int getDoneday() {
		return doneday;
	}

	public MountVO(String title, String startDate, String dayname, String starttime, int pillrecommend, int pilltotal,
			String pillexpire) {
		super();
		this.title = title;
		this.startDate = startDate;
		this.dayname = dayname;
		this.starttime = starttime;
		this.pillrecommend = pillrecommend;
		this.pilltotal = pilltotal;
		this.pillexpire = pillexpire;
	}

	

	public MountVO(String title, String startDate, String dayname, String starttime, int pillrecommend, int pilltotal,
			String pillexpire, String icon, String eachday) {
		super();
		this.title = title;
		this.startDate = startDate;
		this.dayname = dayname;
		this.starttime = starttime;
		this.pillrecommend = pillrecommend;
		this.pilltotal = pilltotal;
		this.pillexpire = pillexpire;
		this.icon = icon;
		this.eachday = eachday;
	}
	public MountVO() {}

	public String getTitle() {
		return title;
	}
	public String getStartDate() {
		return startDate;
	}
	public String getDayname() {
		return dayname;
	}
	public String getStarttime() {
		return starttime;
	}
	public int getPillrecommend() {
		return pillrecommend;
	}
	public int getPilltotal() {
		return pilltotal;
	}
	public String getPillexpire() {
		return pillexpire;
	}
	public String getIcon() {
		return icon;
	}
	public String getEachday() {
		return eachday;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public void setDayname(String dayname) {
		this.dayname = dayname;
	}
	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}
	public void setPillrecommend(int pillrecommend) {
		this.pillrecommend = pillrecommend;
	}
	public void setPilltotal(int pilltotal) {
		this.pilltotal = pilltotal;
	}
	public void setPillexpire(String pillexpire) {
		this.pillexpire = pillexpire;
	}
	public void setIcon(String icon) {
		this.icon = icon;
	}
	public void setEachday(String eachday) {
		this.eachday = eachday;
	}
	@Override
	public String toString() {
		return "MountVO [title=" + title + ", startDate=" + startDate + ", dayname=" + dayname + ", starttime="
				+ starttime + ", pillrecommend=" + pillrecommend + ", pilltotal=" + pilltotal + ", pillexpire="
				+ pillexpire + ", icon=" + icon + ", eachday=" + eachday + "]";
	}
    
}
