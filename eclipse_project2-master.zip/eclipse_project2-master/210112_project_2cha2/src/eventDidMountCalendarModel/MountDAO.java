package eventDidMountCalendarModel;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class MountDAO {
	private java.sql.Connection conn = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;
	private void getConnect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@172.30.1.20:1521:XE";
			String user = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, user, password);

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void getClose() {
		try {
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public String getDatefunc() {

		getConnect();
		String SQL = "SELECT TO_CHAR(SYSDATE, 'dd') FROM DUAL";// �씠嫄곕뒗 �씪�썡�솕�닔紐⑷툑�넗瑜� �젣�뼱�븷 �븣 �벐�젮怨� �븯�뒗 肄붾뱶. 
		String todate = "";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				todate = rs.getString(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}

		return todate;

	}
	public String gettodate() {

		getConnect();
		String SQL = "SELECT TO_CHAR(SYSDATE, 'yyyy-mm-dd') FROM DUAL";// �뜝�떛嫄곕뙋�삕 �뜝�떦�슱�삕�솕�뜝�룞�삕�뜝�룞�삕�뜝�룞�삕鼇앾옙 �뜝�룞�삕�뜝�룞�삕�뜝�룞�삕 �뜝�룞�삕 �뜝�룞�삕�뜝�룞�삕�뜝�룞�삕 �뜝�떦�뙋�삕 �뜝�뙓�벝�삕. 
		String todate = "";

		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);

			rs = pstmt.executeQuery();

			if (rs.next()) {
				todate = rs.getString(1);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}

		return todate;

	}
	public ArrayList<MountVO> listDailyCheck() {
		ArrayList<MountVO> list = new ArrayList<MountVO>();

		try {
			getConnect();
			String sql = "select * from starttable"; 

			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {

				String start=rs.getString("startdate");
				String title = rs.getString("pillname");
				String dayname=rs.getNString("dayname");
				String starttime=rs.getNString("starttime");
				int pillrecommend =rs.getInt("pillrecommend");
				int pilltotal=rs.getInt("pilltotal");
				String pillexpire=rs.getNString("pillexpire");
				
			
				MountVO vo = new MountVO(title, start, dayname, starttime, pillrecommend, pilltotal, pillexpire);
			
			
				
				list.add(vo);

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}

		return list;


	}
	public ArrayList<MountVO> arduinotable() {
		ArrayList<MountVO> list = new ArrayList<MountVO>();

		try {
			getConnect();
			String sql = "select * from arduinotable"; 

			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();
			while (rs.next()) {

				String start=rs.getString("vardate");
				String title = rs.getString("pillname");
				String icon=rs.getNString("icon");
				
				
				
				MountVO vo = new MountVO();
				vo.setStartDate(start);
				vo.setTitle(title);
				vo.setIcon(icon);
			
			
				
				list.add(vo);

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}

		return list;


	}
	public int getDoneday() { // id�뜝�떦�냲�삕�뜝�룞�삕 �뜝�룞�삕�뜝�룞�삕�뜝占� �뜝�룞�삕�뜝�룞�삕 �뜝�룞�삕�뜝�룞�삕. �뜝�뙣�젰�뼲�삕�뜝�룞�삕 �뜝�룞�삕�뜝�룞�삕

		getConnect();
		String sql = "select count(*) from arduinotable";
		int resultCount = 0;
		try {
			
		

				PreparedStatement psmt = conn.prepareStatement(sql);
				rs = psmt.executeQuery();

				if (rs.next())
					resultCount = rs.getInt(1);

			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getClose();
		}

		return resultCount;

	}
}
