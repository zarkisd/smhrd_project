package kr.drug.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import kr.drug.model.MemberVO;

public class MemberDAO {

	
	
	
	
	
	private Connection conn;
	private PreparedStatement psmt;
	private ResultSet rs;


	
	private void getClose() {
		try {
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			System.out.println("�ݱ� ����");
		}
	}
	public MemberDAO() {
		try {
			String dbURL = "jdbc:oracle:thin:@172.30.1.20:1521:XE";
			String dbID = "hr";
			String dbPassword = "hr";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(dbURL, dbID, dbPassword);

		} catch (ClassNotFoundException e) {
			System.out.println("���� ����");
		} catch (SQLException e) {
			System.out.println("sql ���� 1");
		}
	}

	public int login(String id, String pw) {
		String SQL = "SELECT pw FROM member WHERE id = ?";

		try {
			psmt = conn.prepareStatement(SQL);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			if (rs.next()) {
				if (rs.getString(1).contentEquals(pw))
					return 1;
				else
					return 0;
			}
			return -1;
		} catch (Exception e) {
			e.printStackTrace();
		}
		getClose();
		return -2;
	}

//������
	public int join(MemberVO member) {
		String SQL = "INSERT INTO member VALUES (membernum_seq.nextval, ?, ?, ?, ?, ?)";

		try {
			psmt = conn.prepareStatement(SQL);
			psmt.setString(1, member.getId());
			psmt.setString(2, member.getPw());
			psmt.setString(3, member.getName());
			psmt.setString(4, member.getGender());
			psmt.setString(5, member.getEmail());
			return psmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();

		}
		getClose();
		return -1;
	}

	public int getMemberNum(String id) {
		String SQL = "SELECT membernum FROM member WHERE id = ?";

		try {
			psmt = conn.prepareStatement(SQL);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			if (rs.next()) {
				int membernum = rs.getInt(1);
				return membernum;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		getClose();
		return -1;
	}
	
	public String getId(int membernum) {
		String SQL = "SELECT id FROM member WHERE membernum = ?";

		try {
			psmt = conn.prepareStatement(SQL);
			psmt.setInt(1, membernum);
			rs = psmt.executeQuery();
			if (rs.next()) {
				String id = rs.getString(1);
				return id;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		getClose();
		return "";
	}
	
	public ArrayList<MemberVO> memberAllList() {

		ArrayList<MemberVO> list = new ArrayList<MemberVO>();
		String sql = "select * from member";

		try {
			psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();

			while (rs.next()) {
				int membernum = rs.getInt(1);
				String id = rs.getString(2); // ������ ù��° Į�� �������ڴ�.
				String pw = rs.getString(3);
				String name = rs.getString(4);
				String gender = rs.getString(5);
				String email = rs.getString(6);

				MemberVO vo = new MemberVO(membernum, id, pw, name, gender, email); 
				list.add(vo);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			getClose();
		}
		return list;
	}

}
