package kr.drug.model;

public class PillVO {
	private int pillnum;
	private String pillname;
	private String id;
	private int pilltotal;
	private String pillexpire;
	private int pillrecommend;
	private String pillcompany;
	private String startdate;

	private String dayname;
	private String starttime;

	public String getStarttime() {
		return starttime;
	}

	public void setStarttime(String starttime) {
		this.starttime = starttime;
	}

	public PillVO(int pillnum, String pillname, String id, int pilltotal, String pillexpire, int pillrecommend,
			String pillcompany) {
		super();
		this.pillnum = pillnum;
		this.pillname = pillname;
		this.id = id;
		this.pilltotal = pilltotal;
		this.pillexpire = pillexpire;
		this.pillrecommend = pillrecommend;
		this.pillcompany = pillcompany;
	}

	public PillVO(String pillname, String id, int pilltotal, String pillexpire, int pillrecommend, String startdate,
			String dayname, String starttime) {
		super();
		this.pillname = pillname;
		this.id = id;
		this.pilltotal = pilltotal;
		this.pillexpire = pillexpire;
		this.pillrecommend = pillrecommend;

		this.startdate = startdate;
		this.dayname = dayname;
		this.starttime = starttime;
	}

	public String getDayname() {
		return dayname;
	}

	public void setDayname(String dayname) {
		this.dayname = dayname;
	}

	public String getStartdate() {
		return startdate;
	}

	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}

	public PillVO(String pillname, String pillcompany, int pilltotal, String pillexpire, int pillrecommend,
			int pillnum) {
		super();
		this.pillnum = pillnum;
		this.pillname = pillname;
		this.pilltotal = pilltotal;
		this.pillexpire = pillexpire;
		this.pillrecommend = pillrecommend;
		this.pillcompany = pillcompany;

	}

	public PillVO() {
	}

	public void setPillnum(int pillnum) {
		this.pillnum = pillnum;
	}

	public int getPillnum() {
		return pillnum;
	}

	public String getPillname() {
		return pillname;
	}

	public void setPillname(String pillname) {
		this.pillname = pillname;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getPilltotal() {
		return pilltotal;
	}

	public void setPilltotal(int pilltotal) {
		this.pilltotal = pilltotal;
	}

	public String getPillexpire() {
		return pillexpire;
	}

	public void setPillexpire(String pillexpire) {
		this.pillexpire = pillexpire;
	}

	public int getPillrecommend() {
		return pillrecommend;
	}

	public void setPillrecommend(int pillrecommend) {
		this.pillrecommend = pillrecommend;
	}

	public String getPillcompany() {
		return pillcompany;
	}

	public void setPillcompany(String pillcompany) {
		this.pillcompany = pillcompany;
	}

	@Override
	public String toString() {
		return "pillVO [pillnum=" + pillnum + ", pillname=" + pillname + ", id=" + id + ", pilltotal=" + pilltotal
				+ ", pillexpire=" + pillexpire + ", pillrecommend=" + pillrecommend + ", pillcompany=" + pillcompany
				+ "]";
	}

}