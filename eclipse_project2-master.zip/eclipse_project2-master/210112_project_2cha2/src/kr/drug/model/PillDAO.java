package kr.drug.model;

import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class PillDAO {
	private java.sql.Connection conn = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;

	private void getConnect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@172.30.1.20:1521:XE";
			String user = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, user, password);

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	private void getClose() {
		try {
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<PillVO> getpillList(String pill) {
		ArrayList<PillVO> list = new ArrayList<PillVO>();
		getConnect();
		String sql = "select * from pillinfo where pillname like ?";

		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, "%"+pill+"%");
			rs = psmt.executeQuery();
			while (rs.next()) {

				String pillname = rs.getString("pillname");
				int pilltotal = rs.getInt("pilltotal");
				int pillrecommend = rs.getInt("pillrecommend");
				String pillcompany = rs.getString("pillcompany");
				String pillexpire = rs.getString("pillexpire");
				int pillnumber = rs.getInt("pillnum");

				PillVO vo = new PillVO(pillname, pillcompany, pilltotal, pillexpire, pillrecommend, pillnumber);
				list.add(vo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}

		return list;

	}

	public ArrayList<PillVO> getpillList2(int pillnum) {
		ArrayList<PillVO> list = new ArrayList<PillVO>();
		getConnect();
		String sql = "select * from pillInfo where pillnum=?";

		try {
			psmt = conn.prepareStatement(sql);
			psmt.setInt(1, pillnum);
			rs = psmt.executeQuery();
			while (rs.next()) {

				String pillname = rs.getString("pillname");
				int pilltotal = rs.getInt("pilltotal");
				int pillrecommend = rs.getInt("pillrecommend");
				String pillcompany = rs.getString("pillcompany");
				String pillexpire = rs.getString("pillexpire");
				int pillnumber = rs.getInt("pillnum");

				PillVO vo = new PillVO(pillname, pillcompany, pilltotal, pillexpire, pillrecommend, pillnumber);
				list.add(vo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}

		return list;

	}

	public int InsertStart(PillVO vo) {

		getConnect();
		String sql = "INSERT INTO starttable (id,pillname,pillexpire,pillrecommend,pilltotal,startdate,dayname,starttime)"
				+ " VALUES (?, ?, ?, ?,?,?,?,?)";
		System.out.println(vo.getId());
		try {

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, vo.getId());
			psmt.setString(2, vo.getPillname());
			psmt.setString(3, vo.getPillexpire());
			psmt.setInt(4, vo.getPillrecommend());
			psmt.setInt(5, vo.getPilltotal());
			psmt.setString(6, vo.getStartdate());
			psmt.setString(7, vo.getDayname());
			psmt.setNString(8, vo.getStarttime());

			return psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}
		return -1;
	}

	public int getAday() { // id�ϳ��� ����� ���� ����. �޷¾��� ����

		getConnect();
		String sql = "select count(*) from starttable where id='aaa'"; // userid�� �ӽ�.
		// String sql="select count(*) from starttable where userid='?'";
		int resultCount = 0;
		try {

			/*
			 * 
			 * 
			 * 
			 * 
			 * psmt.setInt(1, pillnum); rs=psmt.executeQuery(); while(rs.next()) {
			 * 
			 * 
			 * String pillname=rs.getString("pillname"); int
			 * pilltotal=rs.getInt("pilltotal"); int
			 * pillrecommend=rs.getInt("pillrecommend"); String
			 * pillcompany=rs.getString("pillcompany"); String
			 * pillexpire=rs.getString("pillexpire"); int pillnumber=rs.getInt("pillnum");
			 */

			PreparedStatement psmt = conn.prepareStatement(sql);
			rs = psmt.executeQuery();

			if (rs.next())
				resultCount = rs.getInt(1);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			getClose();
		}

		return resultCount;

	}

	public ArrayList<PillVO> chogi(String id) {
		ArrayList<PillVO> list = new ArrayList<PillVO>();
		getConnect();
		String sql = "select * from starttable where id=?";

		try {
			psmt = conn.prepareStatement(sql);
			psmt.setString(1, id);
			rs = psmt.executeQuery();
			while (rs.next()) {

				String id2 = id;
				String pillname = rs.getString("pillname");
				int pilltotal = rs.getInt("pilltotal");
				int pillrecommend = rs.getInt("pillrecommend");
				String pillexpire = rs.getString("pillexpire");
				String startdate = rs.getNString("startdate");
				String dayname = rs.getNString("dayname");
				String starttime = rs.getNString("starttime");

				PillVO vo = new PillVO(pillname, id2, pilltotal, pillexpire, pillrecommend, startdate, dayname,
						starttime);

				list.add(vo);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}

		return list;

	}

}
