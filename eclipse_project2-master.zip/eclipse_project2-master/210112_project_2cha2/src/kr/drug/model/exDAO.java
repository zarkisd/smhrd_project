package kr.drug.model;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class exDAO {

	private java.sql.Connection conn = null;
	private PreparedStatement psmt = null;
	private ResultSet rs = null;

	private void getConnect() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@172.30.1.20:1521:XE";
			String user = "hr";
			String password = "hr";
			conn = DriverManager.getConnection(url, user, password);

		} catch (ClassNotFoundException e) {
			System.out.println("���� ����");
		} catch (SQLException e) {
			System.out.println("sql ���� 1");
		}
	}

	private void getClose() {
		try {
			if (rs != null)
				rs.close();
			if (psmt != null)
				psmt.close();
			if (conn != null)
				conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int InsertStart(exVO vo) {

		getConnect();
		String sql = "INSERT INTO exexex VALUES (?, ?, ?)";

		try {

			psmt = conn.prepareStatement(sql);
			psmt.setString(1, vo.getAb());
			psmt.setString(2, vo.getAbc());
			psmt.setString(3, vo.getAbcd());

			return psmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {

			getClose();
		}
		return -1;
	}

}

