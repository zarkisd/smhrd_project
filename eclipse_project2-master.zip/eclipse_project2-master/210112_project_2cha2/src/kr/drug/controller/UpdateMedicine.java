package kr.drug.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.drug.frontcontroller.Controller;
import kr.drug.model.PillInfoDAO;
import kr.drug.model.PillInfoVO;

public class UpdateMedicine implements Controller {

	@Override
	public String requestHandler(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		int pillnum = Integer.parseInt(request.getParameter("pillnum"));
		String pillname = request.getParameter("pillname");
		int pilltotal = Integer.parseInt(request.getParameter("pilltotal"));
		int pillrecommend = Integer.parseInt(request.getParameter("pillrecommend"));
		String pillcompany = request.getParameter("pillcompany");
		String pillexpire = request.getParameter("pillexpire");
		String pillcategory = request.getParameter("pillcategory");
		// Ȯ�ο�
		System.out.println(pillnum+" \t"+pillname + " \t" + pillrecommend + " \t" + pilltotal + " \t" + pillcompany + " \t"
				+ pillexpire + " \t" + pillcategory);
		//
		PillInfoDAO dao = new PillInfoDAO();
		PillInfoVO vo = new PillInfoVO(pillnum,pillname, pilltotal, pillrecommend, pillcompany, pillexpire, pillcategory);

		int cnt = dao.update(vo);
		if (cnt > 0) {
			System.out.println("db ���� ����");
			return "admin/adminMedicine.jsp";
		} else {
			throw new ServletException("db ���� ����");
		}

	}

}
