drop table member cascade constraint;
drop table pill cascade constraint;
drop table basic cascade constraint;
drop table dailycheck cascade constraint;
drop table bbs cascade constraint;



create table pill
(pillnum number(20), 
pillname varchar2(20) not null,
pillrecommend varchar2(20) not null, 
pilleffect varchar2(200),
pillcompany varchar2(20) not null,
constraint pill_info_pillnum_pk primary key(pillnum),
constraint pill_info_pillname_uk unique(pillname));

create table basic
(uqnum number(20), 
pilltotal number(20) not null,
pillexpire varchar2(30) not null,
pillnum number(20) not null, 
constraint basic_uqnum_pk primary key(uqnum), 
constraint basic_pillnum_fk foreign key(pillnum) references pill);


create table dailycheck
(uqday number(30), 
pillday varchar2(20) not null, 
pilltime varchar2(20) not null,
pillcheck varchar2(10) not null, 
membernum number(20),
uqnum number(20),
constraint daily_check_uqday primary key(uqday),
constraint daily_check_uqnum foreign key(uqnum) references basic,
constraint daily_check_membernum foreign key(membernum) references member);

create table member
(
membernum number(20), 
id varchar2(25),
pw varchar2(25) not null,
name varchar2(20) not null,
gender varchar2(20),
email varchar2(30), 
constraint member_membernum_pk primary key(membernum), 
constraint member_id_uk unique(id));

create table bbs
(
bbsnum number(30),
membernum number(20) not null, 
bbstitle varchar2(50),
bbscontent varchar2(200),
 bbsdate varchar2(20),
 bbsAvailable number(10),
constraint bbs_bbsnum_pk primary key(bbsnum),
constraint bbs_membernum_fk foreign key(membernum) references member);

select * from member;
select * from bbs;

insert into member values(membernum_seq.nextval, 'admin','1234', 'admin', 'male', 'admin@naver.com');

update bbs set bbsAvailable=1;

drop table bbs cascade constraint;

drop sequence membernum_seq;
drop sequence bbsnum_seq;

create sequence membernum_seq
increment by 1 start with 101; 
create sequence bbsnum_seq
increment by 1 start with 101; 
create sequence pillnum_seq
increment by 1 start with 1;


create sequence pillinfo_seq
increment by 1 start with 1;

drop table pillinfo
drop sequence pillinfo_seq;

create table pillinfo 
(pillnum number(20),
pillname varchar2(30),
pilltotal number(20),
pillrecommend number(20),
pillcompany varchar2(30), 
pillexpire varchar2(30),
pillcategory varchar2(20) );

alter table pillinfo
add constraint info_num_pk primary key(pillnum);

select * from pillinfo;
select * from starttable;

create table starttable
(id varchar2(30),
pillname varchar2(20), 
pillexpire varchar2(30), 
pillrecommend number(20), 
pilltotal number(20), 
startdate varchar2(30),
 dayname varchar2(20), 
 starttime varchar2(30));
 
delete from starttable;
select * from starttable;

insert into pillinfo
values(pillinfo_seq.nextval,'bb',150,1,'bb_b','2021-10-12', 'test');
 insert into pillinfo
values(pillinfo_seq.nextval,'aa',230,1,'aa_a','2021-02-05', 'test');

delete from pillinfo
--�ÿ� ���� �Է��Ұ�
insert into pillinfo
values(pillinfo_seq.nextval,'�ϸ���Ÿ�� ���簡�� Ű��',120,2,'HAMSOA','2022-06-11', 'vitamin');

--�⺻���� �־����ִ� �� ����
insert into pillinfo
values(pillinfo_seq.nextval,'�ԼҾ� ��Ÿ��D 1000 IU',60,1,'HAMSOA','2023-01-08', 'vitamin');
insert into pillinfo
values(pillinfo_seq.nextval,'�ԼҾ� ��Ƽ��Ÿ��',123,1,'HAMSOA','2022-06-11', 'vitamin');
insert into pillinfo
values(pillinfo_seq.nextval,'���ϸ��� ����Ű�� ������',120,2,'���������̿���(��)','2022-06-11', 'lutein');
insert into pillinfo
values(pillinfo_seq.nextval,'Ű��ưư Į��&��Ÿ��D',120,2,'�ϵ�����(��)','2022-06-11', 'calcium');
insert into pillinfo
values(pillinfo_seq.nextval,'���̺�� ưư Į�� PGA �÷���',120,2,'(��)��Ʈ�����̿���','2022-06-11', 'calcium');

select * from pillinfo where pillname like '%��Ÿ%';

select * from arduinotable;



