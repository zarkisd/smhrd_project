package eventDidMountCalendarController;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import eventDidMountCalendarModel.MountDAO;
import eventDidMountCalendarModel.MountVO;

@WebServlet("/eventDidMountCalendar.do")
public class eventDidMountCalendar extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		
		
		ArrayList<ArrayList<MountVO>> newlist2;

		String updateSignal = request.getParameter("updateSignal");

		ArrayList<MountVO> dosingList = new ArrayList<MountVO>();

		MountDAO dao = new MountDAO();

		updateSignal = "3";

		dosingList = dao.listDailyCheck();

		String todate = dao.gettodate();

		ArrayList<MountVO> newlist = new ArrayList<MountVO>();

		newlist2 = new ArrayList<ArrayList<MountVO>>();

		System.out.println("���Դ�?");
		String icon = "images/pill_ready.png";

		int doneday = dao.getDoneday();

		
		
		/*
		 * if(updateSignal==null) { for(int i=0;i<dosingList.size();i++) {
		 * 
		 * newlist =
		 * medicine(dosingList.get(i).getStartDate(),dosingList.get(i).getPilltotal(),
		 * dosingList.get(i).getPillrecommend(),changeday(dosingList.get(i).getDayname()
		 * ),dosingList.get(i).getTitle(),icon); newlist2.add(newlist); } }
		 */
		if (updateSignal != null) {
			for (int i = 0; i < dosingList.size(); i++) {

				newlist = medicine(dosingList.get(i).getStartDate(), dosingList.get(i).getPilltotal(),
						dosingList.get(i).getPillrecommend(), changeday(dosingList.get(i).getDayname()),
						dosingList.get(i).getTitle(), icon, doneday, dosingList.get(i).getPillexpire(), todate);
				newlist2.add(newlist);
				ArrayList<ArrayList<MountVO>> listchanged = new ArrayList<ArrayList<MountVO>>();

				ArrayList<MountVO> updatelist = new ArrayList<MountVO>();
				updatelist = dao.arduinotable();

				for (int k = 0; k < updatelist.size(); k++) {
					newlist2 = selectdays(updatelist.get(k).getStartDate(), newlist2);
				}
			}
		}
		request.setAttribute("list", newlist2);

		RequestDispatcher rd = request.getRequestDispatcher("dailycheck.jsp");
		rd.forward(request, response);

//		else if(updateSignal!=null) { 
//		
//			
//			String newdate="";
//			ArrayList<MountVO> updatelist = new ArrayList<MountVO>();
//			updatelist = dao.arduinotable();
//			
//		selectdays(newdate,newlist2);
//			
//			
//			
//		request.setAttribute("list", newlist2);
//
//		RequestDispatcher rd=request.getRequestDispatcher("/calendarFinal.jsp");
//		rd.forward(request, response);
//		}

	}

	public ArrayList<ArrayList<MountVO>> selectdays(String date, ArrayList<ArrayList<MountVO>> list) {

		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < list.get(i).size(); j++) {
				if ((list.get(i) != null) && (date.equals(list.get(i).get(j).getStartDate()))) {
					list.get(i).get(j).setIcon("images/pill_done.gif");
				}
			}
		}
		return list;
	}

	public static ArrayList<MountVO> medicine(String startday, int total, int checkofDay, int[] dydlf, String pillname,
			String icon, int doneday, String pillexpire, String todate) {

		// 20210101, 20, 12, {2,4,6}

		ArrayList<MountVO> list = new ArrayList<MountVO>();

		Calendar cal = Calendar.getInstance();
		int count = 0;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = null;
		try {
			date = dateFormat.parse(startday);
		} catch (ParseException e) {
			System.out.println("���Ծ�?");
		}
		cal.setTime(date);
		String month = "";
		String day = "";
		while (true) {
			if (count >= total) {
				break;
			}
			for (int i = 0; i < dydlf.length; i++) {
				if ((cal.get(Calendar.DAY_OF_WEEK)) == dydlf[i]) {

					if ((cal.get(Calendar.MONTH) + 1) < 10) {
						month = "0" + (cal.get(Calendar.MONTH) + 1);
					} else {
						month = "" + (cal.get(Calendar.MONTH) + 1);
					}

					if ((cal.get(Calendar.DAY_OF_MONTH) < 10)) {
						day = "0" + cal.get(Calendar.DATE);
					} else {
						day = "" + cal.get(Calendar.DATE);
					}

					MountVO vo = new MountVO();
					vo.setTitle(pillname);
					vo.setIcon(icon);
					vo.setStartDate((cal.get(Calendar.YEAR) + "-" + month + "-" + day));
					vo.setDoneday(doneday);
					vo.setPillexpire(pillexpire);
					vo.setTodate(todate);
					list.add(vo);

					count += checkofDay;
				}

			}
			cal.add(Calendar.DATE, 1);
		}
		for (int i = 0; i < list.size(); i++) {
			System.out.println("newlist>> " + list.get(i));
		}
		return list;
	}

	public int[] changeday(String dayname) {
		int[] result = new int[dayname.length()];
		String[] daynames_ = new String[dayname.length()];
		for (int i = 0; i < dayname.length(); i++) {
			daynames_ = dayname.split("");
			result[i] = Integer.parseInt(daynames_[i]) + 1;
		}
		return result;

	}

//	public void update(String update) {
//		ArrayList<ArrayList<MountVO>> list = new ArrayList<ArrayList<MountVO>>();
//		
//			for (ArrayList<MountVO> list : list)
//			{
//			    if ((list != null) && update.equals(list.get(i).getStartDate())){
//			        list.get(i).setIcon("img/pill_done.png");
//			    }
//			}
//
//		
//	}

}
