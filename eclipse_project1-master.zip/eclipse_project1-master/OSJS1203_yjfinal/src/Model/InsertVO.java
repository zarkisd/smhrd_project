package Model;

public class InsertVO {

	// VO --> Value Object
	// ��ɴ����� ���� �� �ʿ��� �ڷ����� ����
	// ȸ������ ����� �� �� �ʿ��� �ڷ������� ����
	



	//VO --> Value Object
	//��ɴ����� ���� �� �ʿ��� �ڷ����� ����
	//ȸ������ ����� �� �� �ʿ��� �ڷ������� ����
	

	private String member_id, member_pw, name, tel, join_date;
	private int member_n, age;
	
	//�����ڶ� getter,setter �޼ҵ� ����	
	public InsertVO(String member_id, String member_pw, String name, int age, String tel, String join_date) {
		this.member_id = member_id;
		this.member_pw = member_pw;
		this.name = name;
		this.age = age;
		this.tel = tel;
		this.join_date = join_date;
	}
	
	public InsertVO(int member_n, String member_id, String member_pw, String name, int age, String tel, String join_date) {
		this.member_n = member_n;
		this.member_id = member_id;
		this.member_pw = member_pw;
		this.name = name;
		this.age = age;
		this.tel = tel;
		this.join_date = join_date;
	}
	
	//������ �����ε�(id pw�� �޴�!)
	public InsertVO(String member_id, String member_pw) {
		this.member_id = member_id;
		this.member_pw = member_pw;
	}
	
	
	public int getMember_n() {
		return member_n;
	}

	public void setMember_(int member_n) {
		this.member_n = member_n;
	}

	public String getMember_Id() {
		return member_id;
	}

	public String getMember_Pw() {
		return member_pw;
	}

	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}
	
	public String getTel() {
		return tel;
	}

	public String getJoin_date() {
		return join_date;
	}
	
	public void setMember_Id(String member_id) {
		this.member_id = member_id;
	}

	public void setMember_Pw(String member_pw) {
		this.member_pw = member_pw;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public void setTel(String tel) {
		this.tel = tel;
	}

	public void setJoin_date(String join_date) {
		this.join_date = join_date;
	}
	
	private String movie_title, genre, rating;
	private int movie_n;
	
	
	//�����ڶ� getter,setter �޼ҵ� ����
	
	
	public InsertVO(String movie_title, String genre, String rating) {
		this.movie_title = movie_title;
		this.genre = genre;
		this.rating = rating;
	}
	
	public InsertVO(int movie_n, String movie_title, String genre, String rating) {
		this.movie_n = movie_n;
		this.movie_title = movie_title;
		this.genre = genre;
		this.rating = rating;
	}
	public InsertVO(Object movie_title, Object genre, Object rating) {
		this.movie_title = (String) movie_title;
		this.genre = (String) genre;
		this.rating = (String) rating;
	}
	public InsertVO(Object movie_title) {
		this.movie_title = (String) movie_title;
	}

	public String getMovie_title() {
		return movie_title;
	}

	public void setMovie_title(String movie_title) {
		this.movie_title = movie_title;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public int getMovie_n() {
		return movie_n;
	}

	public void setMovie_n(int movie_n) {
		this.movie_n = movie_n;
	}
	
	private String cinema_name, seat_total;
	private int cinema_n;
	
	public InsertVO(int cinema_n, String cinema_name,  String seat_total) {
		this.cinema_n = cinema_n;
		this.cinema_name = cinema_name;
		this.seat_total = seat_total;
	}

	

	public String getCinema_name() {
		return cinema_name;
	}

	public void setCinema_name(String cinema_name) {
		this.cinema_name = cinema_name;
	}

	public String getSeat_total() {
		return seat_total;
	}

	public void setSeat_total(String seat_total) {
		this.seat_total = seat_total;
	}

	public int getCinema_n() {
		return cinema_n;
	}

	public void setCinema_n(int cinema_n) {
		this.cinema_n = cinema_n;
	}

	
	private String seat, status, Y_N;

	public InsertVO(int cinema_n, String cinema_name, String seat, String status, String Y_N) {
		this.cinema_n = cinema_n;
		this.cinema_name = cinema_name;
		this.seat = seat;
		this.status = status;
		this.Y_N = Y_N;
	}
	public InsertVO(String cinema_name, String seat, String status, String Y_N) {
		this.cinema_name = cinema_name;
		this.seat = seat;
		this.status = status;
		this.Y_N = Y_N;
	}

	public String getSeat() {
		return seat;
	}

	public void setSeat(String seat) {
		this.seat = seat;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getY_N() {
		return Y_N;
	}

	public void setY_N(String Y_N) {
		Y_N = Y_N;
	}

	private String  sch_time, sch_date;
	private int sch_n;

	public InsertVO(int sch_n, int cinema_n, String cinema_name, int movie_n, String movie_title,  String sch_date, 
			String sch_time) {
		this.sch_n = sch_n;
		this.cinema_n = cinema_n;
		this.cinema_name = cinema_name;
		this.movie_n = movie_n;
		this.movie_title = movie_title;
		this.sch_date = sch_date;
		this.sch_time = sch_time;
	}

	public String getSch_time() {
		return sch_time;
	}

	public int getSch_n() {
		return sch_n;
	}

	public String getSch_date() {
		return sch_date;
	}

	public void setSch_time(String sch_time) {
		this.sch_time = sch_time;
	}

	public void setSch_n(int sch_n) {
		this.sch_n = sch_n;
	}

	public void setSch_date(String sch_date) {
		this.sch_date = sch_date;
	}

	private String res_date, res_seat;
	private int res_n, res_cnt, res_price;

	public InsertVO(int res_n, String res_date, int member_n, int cinema_n, String cinema_name, int movie_n,
					String movie_title, String sch_date, String sch_time, String res_seat, int res_cnt, int res_price) {
		this.res_n = res_n;
		this.res_date = res_date;
		this.member_n = member_n;
		this.cinema_n = cinema_n;
		this.cinema_name = cinema_name;
		this.movie_n = movie_n;
		this.movie_title = movie_title;
		this.sch_date = sch_date;
		this.sch_time = sch_time;
		this.res_seat = res_seat;
		this.res_cnt = res_cnt;
		this.res_price = res_price;
		
	}

	public String getRes_date() {
		return res_date;
	}

	public String getRes_seat() {
		return res_seat;
	}

	public int getRes_n() {
		return res_n;
	}

	public int getRes_cnt() {
		return res_cnt;
	}

	public int getRes_price() {
		return res_price;
	}

	public void setRes_date(String res_date) {
		this.res_date = res_date;
	}

	public void setRes_seat(String res_seat) {
		this.res_seat = res_seat;
	}

	public void setRes_n(int res_n) {
		this.res_n = res_n;
	}

	public void setRes_cnt(int res_cnt) {
		this.res_cnt = res_cnt;
	}

	public void setRes_price(int res_price) {
		this.res_price = res_price;
	}


	
	
	
	

}
