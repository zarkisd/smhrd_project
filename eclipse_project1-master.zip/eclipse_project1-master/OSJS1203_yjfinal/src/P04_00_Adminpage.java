
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import DAO.DAO;
import Model.InsertVO;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JButton;
import java.awt.CardLayout;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class P04_00_Adminpage {

	private JFrame frame;
	private JTable table;
	private JTable table_1;
	private JTable table_2;
	private JTable table_3;
	private ArrayList<InsertVO> list;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P04_00_Adminpage window = new P04_00_Adminpage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P04_00_Adminpage() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(400, 100, 983, 713);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 0, 950, 600);
		frame.getContentPane().add(tabbedPane);
		DAO dao = new DAO();
		list = dao.allSelect();
		String[] column = {"MEMBER_N","MEMBER_id","MEMBER_pw","Name","Age","Tel","Join Date"};
		//data�� ����ִ� object(�ֻ��� Ŭ����) 2���� �迭
		Object[][] data = new Object[list.size()][column.length];
		
		//q1.�������迭 �����
		for (int i = 0; i < list.size(); i++) {
			
			data[i][0] = list.get(i).getMember_n();
			data[i][1] = list.get(i).getMember_Id();
			data[i][2] = list.get(i).getMember_Pw();
			data[i][3] = list.get(i).getName();
			data[i][4] = list.get(i).getAge();
			data[i][5] = list.get(i).getTel();
			data[i][6] = list.get(i).getJoin_date();
		}
		
		JScrollPane scrollPane = new JScrollPane();
		tabbedPane.addTab("MEMBER", null, scrollPane, null);
		//		for (int j = 0; j < data.length; j++) {
		//			for (int i = 0; i < data[j].length; i++) {
		//				System.out.println(data[j][i]);
		//			}
		//			System.out.println();
		//		}
				
				
				table = new JTable();
				scrollPane.setViewportView(table);
				//table ������ �߰�
				table.setModel(new DefaultTableModel(data, column));
		//
		
		
		
		JScrollPane scrollPane_1 = new JScrollPane();
		tabbedPane.addTab("MOVIE", null, scrollPane_1, null);
		DAO daoM = new DAO();
		list = daoM.allSelectM();
		
		
		String[] columnM = {"Movie_n","Movie_title","Genre","Rating"};
		//data�� ����ִ� object(�ֻ��� Ŭ����) 2���� �迭
		Object[][] dataM = new Object[list.size()][column.length];
		
		//q1.�������迭 �����
		for (int i = 0; i < list.size(); i++) {
			
			dataM[i][0] = list.get(i).getMovie_n();
			dataM[i][1] = list.get(i).getMovie_title();
			dataM[i][2] = list.get(i).getGenre();
			dataM[i][3] = list.get(i).getRating();
		}
//		for (int j = 0; j < dataM.length; j++) {
//			for (int i = 0; i < dataM[j].length; i++) {
//				System.out.println(dataM[j][i]);
//			}
//			System.out.println();
//		}
		
		
		table = new JTable();
		scrollPane_1.setViewportView(table);
		//table ������ �߰�
		table.setModel(new DefaultTableModel(dataM, columnM));
		//
	
		
		JScrollPane scrollPane_2 = new JScrollPane();
		tabbedPane.addTab("CINEMA", null, scrollPane_2, null);
		DAO daoC = new DAO();
		list = daoC.allSelectC();
		String[] columnC = {"Cinema_n","Cinema_Name","Seat_total"};
		//data�� ����ִ� object(�ֻ��� Ŭ����) 2���� �迭
		Object[][] dataC = new Object[list.size()][column.length];
		
		//q1.�������迭 �����
		for (int i = 0; i < list.size(); i++) {
			
			dataC[i][0] = list.get(i).getCinema_n();
			dataC[i][1] = list.get(i).getCinema_name();
			dataC[i][2] = list.get(i).getSeat_total();
			
		}
//		for (int j = 0; j < dataC.length; j++) {
//			for (int i = 0; i < dataC[j].length; i++) {
//				System.out.println(dataC[j][i]);
//			}
//			System.out.println();
//		}
		table = new JTable();
		scrollPane_2.setViewportView(table);
		//table ������ �߰�
		table.setModel(new DefaultTableModel(dataC, columnC));
		
		JScrollPane scrollPane_5 = new JScrollPane();
		tabbedPane.addTab("SEAT", null, scrollPane_5, null);
		
		DAO daoST = new DAO();
		
		list = daoST.allSelectST();
		String[] columnST = {"Cinema_n","Cinema_Name","Seat","Status","Y_N"};
		//data�� ����ִ� object(�ֻ��� Ŭ����) 2���� �迭
		Object[][] dataST = new Object[list.size()][column.length];
		
		//q1.�������迭 �����
		for (int i = 0; i < list.size(); i++) {
			
			dataST[i][0] = list.get(i).getCinema_n();
			dataST[i][1] = list.get(i).getCinema_name();
			dataST[i][2] = list.get(i).getSeat();
			dataST[i][3] = list.get(i).getStatus();
			dataST[i][4] = list.get(i).getY_N();
		}
//		for (int j = 0; j < dataST.length; j++) {
//			for (int i = 0; i < dataST[j].length; i++) {
//				System.out.println(dataST[j][i]);
//			}
//			System.out.println();
//		}
		table = new JTable();
		scrollPane_5.setViewportView(table);
		//table ������ �߰�
		table.setModel(new DefaultTableModel(dataST, columnST));
		
		
		
		JScrollPane scrollPane_3 = new JScrollPane();
		tabbedPane.addTab("SCHEDULE", null, scrollPane_3, null);
		DAO daoS = new DAO();
		list = daoS.allSelectS();
		String[] columnS = {"Sch_n", "Cinema_id", "Cinema_name", "Movie_id", "Movie_title", "Sch_date", "Sch_time"};
		//data�� ����ִ� object(�ֻ��� Ŭ����) 2���� �迭
		Object[][] dataS = new Object[list.size()][column.length];
		
		//q1.�������迭 �����
		for (int i = 0; i < list.size(); i++) {
			
			dataS[i][0] = list.get(i).getSch_n();
			dataS[i][1] = list.get(i).getCinema_n();
			dataS[i][2] = list.get(i).getCinema_name();
			dataS[i][3] = list.get(i).getMovie_n();
			dataS[i][4] = list.get(i).getMovie_title();
			dataS[i][5] = list.get(i).getSch_date();
			dataS[i][6] = list.get(i).getSch_time();
		}
//		for (int j = 0; j < dataS.length; j++) {
//			for (int i = 0; i < dataS[j].length; i++) {
//				System.out.println(dataS[j][i]);
//			}
//			System.out.println();
//		}
		table = new JTable();
		scrollPane_3.setViewportView(table);
		//table ������ �߰�
		table.setModel(new DefaultTableModel(dataS, columnS));
		
		
		JScrollPane scrollPane_4 = new JScrollPane();
		tabbedPane.addTab("RESERVATION", null, scrollPane_4, null);
		DAO daoR = new DAO();
		list = daoR.allSelectR();
		String[] columnR = {"Res_n", "Res_Date","Member_n","Cinema_n","Cinema_name","movie_n",
				"Movie_title","Sch_Date","Sch_Time","Res_seat","Res_Cnt","Res_Price"};
		//data�� ����ִ� object(�ֻ��� Ŭ����) 2���� �迭
		Object[][] dataR = new Object[list.size()][columnR.length];
		
		//q1.�������迭 �����
		for (int i = 0; i < list.size(); i++) {
			
			dataR[i][0] = list.get(i).getRes_n();
			dataR[i][1] = list.get(i).getRes_date();
			dataR[i][2] = list.get(i).getMovie_n();
			dataR[i][3] = list.get(i).getCinema_n();
			dataR[i][4] = list.get(i).getCinema_name();
			dataR[i][5] = list.get(i).getMovie_n();
			dataR[i][6] = list.get(i).getMovie_title();
			dataR[i][7] = list.get(i).getSch_date();
			dataR[i][8] = list.get(i).getSch_time();
			dataR[i][9] = list.get(i).getRes_seat();
			dataR[i][10] = list.get(i).getRes_cnt();
			dataR[i][11] = list.get(i).getRes_price();
		}
//		for (int j = 0; j < dataR.length; j++) {
//			for (int i = 0; i < dataR[j].length; i++) {
//				System.out.println(dataR[j][i]);
//			}
//			System.out.println();
//		}
		table = new JTable();
		scrollPane_4.setViewportView(table);
		//table ������ �߰�
		table.setModel(new DefaultTableModel(dataR, columnR));
		
		
		
		
		JButton btnNewButton = new JButton("\uD68C\uC6D0\uB4F1\uB85D");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				P04_01_Insert.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		btnNewButton.setBounds(12, 610, 97, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\uD68C\uC6D0\uD0C8\uD1F4");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_02_Delete.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
				
			}
		});
		btnNewButton_1.setBounds(12, 636, 97, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\uC601\uD654\uCD94\uAC00");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_03_InsertM.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			
			}
		});
		btnNewButton_2.setBounds(121, 610, 97, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("\uC601\uD654\uC0AD\uC81C");
		btnNewButton_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				P04_04_DeleteM.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
				
			}
		});
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2_1.setBounds(121, 636, 97, 23);
		frame.getContentPane().add(btnNewButton_2_1);
		
		JButton btnNewButton_3 = new JButton("\uC0C1\uC601\uAD00\uCD94\uAC00");
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_05_InsertC.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.setBounds(234, 610, 110, 23);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("\uC0C1\uC601\uAD00\uC0AD\uC81C");
		btnNewButton_3_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_06_DeleteC.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton_3_1.setBounds(234, 636, 110, 23);
		frame.getContentPane().add(btnNewButton_3_1);
		
		JButton btnNewButton_4 = new JButton("\uC88C\uC11D\uCD94\uAC00");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_07_InsertST.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
				
			}
		});
		btnNewButton_4.setBounds(356, 610, 97, 23);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_4_1 = new JButton("\uC88C\uC11D\uC0AD\uC81C");
		btnNewButton_4_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_08_DeleteST.main(null);
				
				frame.dispose();
				
			}
		});
		btnNewButton_4_1.setBounds(356, 636, 97, 23);
		frame.getContentPane().add(btnNewButton_4_1);
		
		JButton btnNewButton_5_1 = new JButton("\uC2A4\uCF00\uC904\uC0AD\uC81C");
		btnNewButton_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_5_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_09_DeleteS.main(null);
				frame.dispose();
			}
		});
		btnNewButton_5_1.setBounds(611, 610, 110, 23);
		frame.getContentPane().add(btnNewButton_5_1);
		
		JButton btnNewButton_6 = new JButton("CSV");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				updateM.main(null);
				frame.dispose();
				
			}
		});
	
		btnNewButton_6.setBounds(842, 610, 97, 23);
		frame.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_5_1_1 = new JButton("\uC608\uC57D\uC0AD\uC81C");
		btnNewButton_5_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				P04_10_DeleteR.main(null);
				frame.dispose();
			}
		});
		btnNewButton_5_1_1.setBounds(733, 610, 97, 23);
		frame.getContentPane().add(btnNewButton_5_1_1);
	
	}
}
