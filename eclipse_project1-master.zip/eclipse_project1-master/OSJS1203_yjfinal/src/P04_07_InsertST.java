
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;

import DAO.DAO;
import Model.InsertVO;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;

public class P04_07_InsertST {

	private JFrame frame;
	private JTextField txt_cinema_name;
	private JTextField txt_seat;
	private JButton btn_inset;
	private JButton btnNewButton;
	private JLabel lbl_status;
	private JTextField txt_status;
	private JLabel lbl_Y_N;
	private JTextField txt_Y_N;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P04_07_InsertST window = new P04_07_InsertST();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public P04_07_InsertST() {
		initialize();
	}


	private void initialize() {
		frame = new JFrame();
		frame.setBounds(400, 100, 512, 417);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbl_title = new JLabel("\uC88C\uC11D\uCD94\uAC00");
		lbl_title.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_title.setFont(new Font("���� ����", Font.BOLD, 19));
		lbl_title.setBounds(159, 10, 156, 47);
		frame.getContentPane().add(lbl_title);
		
		JLabel lbl_cinema_name = new JLabel("\uC0C1\uC601\uAD00");
		lbl_cinema_name.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_cinema_name.setFont(new Font("���� ����", Font.BOLD, 15));
		lbl_cinema_name.setBounds(38, 63, 74, 41);
		frame.getContentPane().add(lbl_cinema_name);
		
		txt_cinema_name = new JTextField();
		txt_cinema_name.setBounds(124, 64, 325, 42);
		frame.getContentPane().add(txt_cinema_name);
		txt_cinema_name.setColumns(10);
		
		JLabel lbl_seat = new JLabel("\uC88C\uC11D");
		lbl_seat.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_seat.setFont(new Font("���� ����", Font.BOLD, 15));
		lbl_seat.setBounds(38, 126, 64, 41);
		frame.getContentPane().add(lbl_seat);
		
		txt_seat = new JTextField();
		txt_seat.setColumns(10);
		txt_seat.setBounds(124, 127, 325, 41);
		frame.getContentPane().add(txt_seat);
		
		btn_inset = new JButton("\uC88C\uC11D \uCD94\uAC00\uD558\uAE30");
		btn_inset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_inset.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				//textfield�� �ִ� ���� ������ �ͼ� ������ ����
				String cinema_name = txt_cinema_name.getText();
				String seat = txt_seat.getText();
				String status = txt_status.getText();
				String Y_N = txt_Y_N.getText();
				
												
				// age --> ������
				//Integer.parseInt
				//InsertVO vo = new InsertVO(id, pw, name, age);
				// - > vo�� ������� �ʱ� ������ ������ �������� �ο�x
				// DAO Ŭ������ ������ �ִ� insert ����� ���!
				// 1. DAOŬ���� �ҷ�����
				DAO dao = new DAO();
				// 2. DAOŬ���� insert��� ����
				// result - > ������ ���� ���� ����
				int result = dao.insertST(new InsertVO(cinema_name, seat, status, Y_N));
					
				if(result > 0) {
					
					//�˾�â ����!
					JOptionPane.showMessageDialog(null, "�¼��߰� ����!", "�¼��߰� ����â",JOptionPane.INFORMATION_MESSAGE);
					// showMessageDialog(�θ�������Ʈ, ����� �޼���, ����, ������)	
					P04_00_Adminpage.main(null);
					frame.dispose();
				}else {
					JOptionPane.showMessageDialog(null, "�¼��߰� ����!", "�¼��߰� ����â", JOptionPane.ERROR_MESSAGE);
				}
				txt_cinema_name.setText("");	
				txt_seat.setText("");	
				txt_status.setText("");	
				txt_Y_N.setText("");	
				
//				System.out.println(id + pw + name + age);				
				//ex01Login���� �̵�
				
				
				//���� â�� �ݱ�
				
				
				
			}
		});
		btn_inset.setFont(new Font("���� ����", Font.BOLD, 13));
		btn_inset.setBounds(126, 318, 195, 33);
		frame.getContentPane().add(btn_inset);
		
		btnNewButton = new JButton("\uCDE8\uC18C");
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 13));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_00_Adminpage.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(333, 318, 116, 30);
		frame.getContentPane().add(btnNewButton);
		
		lbl_status = new JLabel("\uC0C1\uD0DC");
		lbl_status.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_status.setFont(new Font("���� ����", Font.BOLD, 15));
		lbl_status.setBounds(38, 191, 64, 41);
		frame.getContentPane().add(lbl_status);
		
		txt_status = new JTextField();
		txt_status.setColumns(10);
		txt_status.setBounds(124, 192, 325, 41);
		frame.getContentPane().add(txt_status);
		
		lbl_Y_N = new JLabel("Y/N");
		lbl_Y_N.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_Y_N.setFont(new Font("���� ����", Font.BOLD, 15));
		lbl_Y_N.setBounds(38, 256, 64, 41);
		frame.getContentPane().add(lbl_Y_N);
		
		txt_Y_N = new JTextField();
		txt_Y_N.setColumns(10);
		txt_Y_N.setBounds(124, 257, 325, 41);
		frame.getContentPane().add(txt_Y_N);
		


	}
}
