
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import DAO.DAO;
import Model.InsertVO;
import javax.swing.Icon;
import javax.swing.ImageIcon;

public class P03_05_Mypage {

	private JFrame frame;

	private ArrayList<InsertVO> list, list1;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P03_05_Mypage window = new P03_05_Mypage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P03_05_Mypage() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.WHITE);
		frame.setBounds(500, 150, 360, 580);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		frame.getContentPane().add(panel, "name_316077958234000");
		panel.setLayout(null);
		
		// ���� ���� �ϴ� Ȩ��ư
				System.out.println(getClass().getResource("").getPath());
				String url = getClass().getResource("").getPath() + "home_home.png";
				Image image = new ImageIcon(url).getImage();
				image = image.getScaledInstance(30, 30, Image.SCALE_SMOOTH);


		JPanel panel_7 = new JPanel();
		panel_7.setBounds(0, 0, 667, 145);
		panel_7.setLayout(null);
		panel_7.setBackground(new Color(106, 90, 205));
		panel.add(panel_7);

		JLabel lblNewLabel_5 = new JLabel("\uC2A4\uB9C8\uD2B8\uADF8\uB9AC\uB4DC \uB2D8");
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setFont(new Font("���� ����", Font.BOLD, 24));
		lblNewLabel_5.setBounds(89, 50, 170, 43);
		panel_7.add(lblNewLabel_5);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(Color.WHITE);
		tabbedPane.setBounds(0, 164, 667, 525);
		panel.add(tabbedPane);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		tabbedPane.addTab("����Ȯ��", null, panel_1, null);
		panel_1.setLayout(null);

		JLabel lbl_Label_2 = new JLabel("\u2714\uC81C\uBAA9");
		lbl_Label_2.setBounds(50, 57, 92, 24);
		lbl_Label_2.setFont(new Font("���� ����", Font.BOLD, 16));
		panel_1.add(lbl_Label_2);

		JLabel lbl_Label_3 = new JLabel("\u2714\uC88C\uC11D\uC815\uBCF4");
		lbl_Label_3.setBounds(50, 124, 92, 24);
		lbl_Label_3.setFont(new Font("���� ����", Font.BOLD, 16));
		panel_1.add(lbl_Label_3);

		JLabel lbl_Label_5 = new JLabel("\u2714\uC0C1\uC601\uC2DC\uAC04");
		lbl_Label_5.setBounds(50, 255, 92, 24);
		lbl_Label_5.setFont(new Font("���� ����", Font.BOLD, 16));
		panel_1.add(lbl_Label_5);

		JLabel lbl_Label_4 = new JLabel("\u2714\uB9E4\uC218");
		lbl_Label_4.setBounds(50, 200, 92, 24);
		lbl_Label_4.setFont(new Font("���� ����", Font.BOLD, 16));
		panel_1.add(lbl_Label_4);

		DAO dao = new DAO();
		list = dao.allSelectCheck(P02_01_Login.login_id);
//		
		JLabel lbl_name = new JLabel(list.get(0).getMovie_title());
		lbl_name.setBounds(154, 63, 174, 18);
		panel_1.add(lbl_name);

		JLabel lbl_seat = new JLabel(list.get(0).getRes_seat());
		lbl_seat.setBounds(154, 124, 120, 18);
		panel_1.add(lbl_seat);

		JLabel lbl_time = new JLabel(list.get(0).getSch_time());
		lbl_time.setBounds(154, 261, 120, 18);
		panel_1.add(lbl_time);

		JLabel lbl_cnt = new JLabel(P03_01_Booking.c + "");
		lbl_cnt.setBounds(154, 206, 120, 18);
		panel_1.add(lbl_cnt);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.WHITE);
		tabbedPane.addTab("��������", null, panel_2, null);
		panel_2.setLayout(null);

		JButton btnNewButton = new JButton("\uD68C\uC6D0\uD0C8\uD1F4");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// ȸ��Ż�� Ŭ����
				P02_03Delete.main(null);
				frame.dispose();

			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton.setBackground(new Color(106, 90, 205));
		btnNewButton.setBounds(214, 300, 97, 34);
		panel_2.add(btnNewButton);

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel.setBounds(80, 34, 57, 15);
		panel_2.add(lblNewLabel);

		list1 = dao.allSelectFinish(P02_01_Login.login_id);

		JLabel lbl_ID = new JLabel(list1.get(0).getMember_Id());
		lbl_ID.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_ID.setBounds(188, 34, 57, 15);
		panel_2.add(lbl_ID);

		JLabel lblPwddddd = new JLabel("PW");
		lblPwddddd.setFont(new Font("���� ����", Font.BOLD, 15));
		lblPwddddd.setBounds(80, 73, 57, 15);
		panel_2.add(lblPwddddd);

		JLabel lbl_PW = new JLabel(list1.get(0).getMember_Pw());
		lbl_PW.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_PW.setBounds(188, 73, 57, 15);
		panel_2.add(lbl_PW);

		JLabel lblNewLabel_3 = new JLabel("\uC774\uB984");
		lblNewLabel_3.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_3.setBounds(80, 131, 57, 15);
		panel_2.add(lblNewLabel_3);

		JLabel lbl_name1 = new JLabel(list1.get(0).getName());
		lbl_name1.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_name1.setBounds(188, 131, 57, 15);
		panel_2.add(lbl_name1);

		JLabel lblNewLabel_4 = new JLabel("\uB098\uC774");
		lblNewLabel_4.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_4.setBounds(80, 186, 57, 15);
		panel_2.add(lblNewLabel_4);

		JLabel lbl_age = new JLabel(list1.get(0).getAge() + "");
		lbl_age.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_age.setBounds(188, 186, 57, 15);
		panel_2.add(lbl_age);

		JLabel lblNewLabel_6 = new JLabel("\uC5F0\uB77D\uCC98");
		lblNewLabel_6.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_6.setBounds(80, 234, 57, 15);
		panel_2.add(lblNewLabel_6);

		JLabel lbl_tel = new JLabel(list1.get(0).getTel());
		lbl_tel.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_tel.setBounds(188, 234, 146, 15);
		panel_2.add(lbl_tel);
		
		JButton btn_home = new JButton(new ImageIcon(image));
		btn_home.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// Ȩȭ�� ��ư ������ Ȩ���� �Ѿ��
				P03_00_MainHomepage.main(null);
				frame.dispose();
			}
		});
		btn_home.setBounds(24, 300, 53, 34);
		panel_2.add(btn_home);
		btn_home.setBackground(new Color(106, 90, 205));

	}
}
