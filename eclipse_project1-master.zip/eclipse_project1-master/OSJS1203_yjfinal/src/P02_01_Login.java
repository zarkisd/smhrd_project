import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;

import DAO.DAO;
import Model.InsertVO;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class P02_01_Login {

	private JFrame frame;
	private JTextField txt_id;
	private JTextField txt_pw;
	static String login_id;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P02_01_Login window = new P02_01_Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P02_01_Login() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(700, 300, 371, 376); // �α���â �߾ӿ� ���� x,y����
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lbl_title = new JLabel("\uB85C\uADF8\uC778 \uC2DC\uC2A4\uD15C");
		lbl_title.setBackground(new Color(255, 255, 255));
		lbl_title.setFont(new Font("���� ����", Font.BOLD, 16));
		lbl_title.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_title.setBounds(12, 22, 331, 73);
		frame.getContentPane().add(lbl_title);

		JLabel lbl_id = new JLabel("ID");
		lbl_id.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_id.setFont(new Font("���� ����", Font.BOLD, 14));
		lbl_id.setBounds(22, 105, 34, 31);
		frame.getContentPane().add(lbl_id);

		txt_id = new JTextField();
		txt_id.setBounds(65, 105, 259, 31);
		frame.getContentPane().add(txt_id);
		txt_id.setColumns(10);

		JLabel lbl_pw = new JLabel("PW");
		lbl_pw.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_pw.setFont(new Font("���� ����", Font.BOLD, 14));
		lbl_pw.setBounds(22, 151, 34, 32);
		frame.getContentPane().add(lbl_pw);

		txt_pw = new JTextField();
		txt_pw.setColumns(10);
		txt_pw.setBounds(65, 151, 259, 32);
		frame.getContentPane().add(txt_pw);

		JButton btn_login = new JButton("\uB85C\uADF8\uC778");
		btn_login.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				// 1. txt_id, txt_pw�� �ִ� �ؽ�Ʈ�� ������ �´�.
				String id = txt_id.getText();
				String pw = txt_pw.getText();
				login_id = id;
//				// 2. �� ������ InsertVO �����ֱ�
//				InsertVO vo = new InsertVO(id, pw);
				if (id.equals("admin") && pw.equals("1234")) {
					P04_00_Adminpage.main(null);
					frame.dispose();
				} else {
					// 3. DAO����
					DAO dao = new DAO();

					// 3. dao�ȿ� select��� ����!
					String resultPw = dao.select(id);

					if (resultPw.equals(pw)) {
						System.out.println("�α��� ����");

						JOptionPane.showMessageDialog(null, "�α��� ����!", "�α��� ����â", JOptionPane.INFORMATION_MESSAGE);

						P03_00_MainHomepage.main(null);
						// P04_Mypage.main(null);
						frame.dispose();
					} else {
						System.out.println("�α��� ����");
						JOptionPane.showMessageDialog(null, "�α��� ����", "�α��� ����â", JOptionPane.INFORMATION_MESSAGE);
						P02_01_Login.main(null);
						frame.dispose();
					}
				}
			}
		});
		btn_login.setBackground(new Color(106, 90, 205));
		btn_login.setForeground(new Color(255, 255, 255));
		btn_login.setFont(new Font("���� ����", Font.BOLD, 15));
		btn_login.setBounds(35, 216, 289, 32);
		frame.getContentPane().add(btn_login);

		JButton btn_inset = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btn_inset.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				// P02_02_Insert�� �̵�!!!ȸ������â
				P02_02_Insert.main(null);

				// ���� â�� �ݱ�
				frame.dispose();

			}
		});
		btn_inset.setBackground(new Color(106, 90, 205));
		btn_inset.setForeground(new Color(255, 255, 255));
		btn_inset.setFont(new Font("���� ����", Font.BOLD, 15));
		btn_inset.setBounds(35, 260, 289, 32);
		frame.getContentPane().add(btn_inset);
	}

}
