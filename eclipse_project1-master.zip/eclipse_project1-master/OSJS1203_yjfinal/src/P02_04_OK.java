

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DAO.DAO;
import java.awt.Color;

public class P02_04_OK {

	private JFrame frame;
	private JTextField txt_id;
	private JTextField txt_pw;
	private static String name;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P02_04_OK window = new P02_04_OK(name);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P02_04_OK(String name) {
		initialize(name);
		frame.setVisible(true);
	}

	private void initialize(String name) {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(700, 250, 411, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lbl_name = new JLabel("\uD0C8\uD1F4 \uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?"); // ���⿡ name ���� ������ â�� �̸� ������
																							// �ʴ´�!!!
		lbl_name.setFont(new Font("���� ����", Font.BOLD, 18));
		lbl_name.setBounds(126, 133, 174, 52);
		frame.getContentPane().add(lbl_name);

		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.setBackground(new Color(106, 90, 205));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				DAO dao = new DAO();
				
				String id = txt_id.getText();
				String pw = txt_pw.getText();
				
				int cnt = dao.delete(id, pw);
				System.out.println(cnt);
				if(cnt > 0) {
					System.out.println("ȸ��Ż�� ����");
					frame.dispose();
				}else {
					System.out.println("ȸ��Ż�� ����");
					txt_id.setText("");
					txt_pw.setText("");
					
				}
			
			}
		});
		
		btnNewButton.setBounds(94, 195, 97, 35);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1.setBackground(new Color(106, 90, 205));
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		btnNewButton_1.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P02_01_Login.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(203, 195, 97, 35);
		frame.getContentPane().add(btnNewButton_1);

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(26, 49, 57, 15);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblPw = new JLabel("PW");
		lblPw.setFont(new Font("���� ����", Font.BOLD, 14));
		lblPw.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw.setBounds(26, 94, 57, 15);
		frame.getContentPane().add(lblPw);

		txt_id = new JTextField();
		txt_id.setBounds(95, 39, 250, 35);
		frame.getContentPane().add(txt_id);
		txt_id.setColumns(10);

		txt_pw = new JTextField();
		txt_pw.setColumns(10);
		txt_pw.setBounds(95, 84, 250, 35);
		frame.getContentPane().add(txt_pw);
	}
}
