

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DAO.DAO;

public class P04_09_DeleteS {

	private JFrame frame;
	private JTextField txt_movie_title;
	private JTextField txt_sch_time;
	private static String name;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P04_09_DeleteS window = new P04_09_DeleteS(name);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P04_09_DeleteS(String name) {
		initialize(name);
		frame.setVisible(true);
	}

	private void initialize(String name) {
		frame = new JFrame();
		frame.setBounds(400, 100, 500, 373);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lbl_name = new JLabel("\uC2A4\uCF00\uC904\uC744 \uC0AD\uC81C\uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?"); // ���⿡ name ���� ������ â�� �̸� ������
																							// �ʴ´�!!!
		lbl_name.setFont(new Font("���� ����", Font.PLAIN, 17));
		lbl_name.setBounds(134, 215, 268, 46);
		frame.getContentPane().add(lbl_name);

		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				DAO dao = new DAO();
				
				String movie_title = txt_movie_title.getText();
				String sch_time = txt_sch_time.getText();
				
				int cnt = dao.deleteS(movie_title, sch_time);
				System.out.println(cnt);
				if(cnt > 0) {
					System.out.println("�����ٻ����Ϸ�");
					P04_00_Adminpage.main(null);
					frame.dispose();
				}else {
					System.out.println("�����ٻ�������");
					txt_movie_title.setText("");
					txt_sch_time.setText("");
				}
			
			}
		});
		
		btnNewButton.setBounds(130, 272, 97, 33);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_00_Adminpage.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(239, 272, 97, 33);
		frame.getContentPane().add(btnNewButton_1);

		JLabel lb_movie_title = new JLabel("\uC601\uD654\uC81C\uBAA9");
		lb_movie_title.setFont(new Font("���� ����", Font.BOLD, 14));
		lb_movie_title.setHorizontalAlignment(SwingConstants.CENTER);
		lb_movie_title.setBounds(48, 96, 57, 29);
		frame.getContentPane().add(lb_movie_title);

		JLabel lbl_sch_time = new JLabel("\uC601\uD654\uC2DC\uAC04");
		lbl_sch_time.setFont(new Font("���� ����", Font.BOLD, 14));
		lbl_sch_time.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_sch_time.setBounds(48, 153, 57, 33);
		frame.getContentPane().add(lbl_sch_time);

		txt_movie_title = new JTextField();
		txt_movie_title.setBounds(117, 88, 308, 46);
		frame.getContentPane().add(txt_movie_title);
		txt_movie_title.setColumns(10);

		txt_sch_time = new JTextField();
		txt_sch_time.setColumns(10);
		txt_sch_time.setBounds(117, 150, 308, 46);
		frame.getContentPane().add(txt_sch_time);
		
		JLabel lblNewLabel_1 = new JLabel("\uC2A4\uCF00\uC904\uC0AD\uC81C");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(117, 32, 244, 29);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
