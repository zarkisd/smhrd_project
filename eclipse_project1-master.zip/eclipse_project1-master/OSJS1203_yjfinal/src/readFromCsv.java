import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class readFromCsv {

	public static void main(String[] args) {
		String url = "C:\\Users\\SMHRD\\Desktop\\MovieInfo.csv";
		List<List<String>> list = run(url, "euc-kr");

		// System.out.println(list.get(1).get(0));
	}

	public static List<List<String>> run(String path, String encoding) {
		BufferedReader br = null;
		List<List<String>> list = new ArrayList<List<String>>();
		String line;
		String cvsSplitBy = ",(?=([^\"]*\"[^\"]*\")*[^\"]*$)";

		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(path), encoding));

			while ((line = br.readLine()) != null) {
				List<String> tmpList = new ArrayList<String>();
				String[] field = line.split(cvsSplitBy, -1);
				tmpList = Arrays.asList(field);
				list.add(tmpList);
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return list;

	}

}
