

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DAO.DAO;

public class P04_04_DeleteM {

	private JFrame frame;
	private JTextField txt_movie;
	private static String name;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P04_04_DeleteM window = new P04_04_DeleteM(name);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P04_04_DeleteM(String name) {
		initialize(name);
		frame.setVisible(true);
	}

	private void initialize(String name) {
		frame = new JFrame();
		frame.setBounds(400, 100, 411, 318);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lbl_title = new JLabel("\uC601\uD654\uB97C \uC0AD\uC81C \uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?"); // ���⿡ name ���� ������ â�� �̸� ������
																							// �ʴ´�!!!
		lbl_title.setFont(new Font("���� ����", Font.PLAIN, 17));
		lbl_title.setBounds(100, 73, 201, 46);
		frame.getContentPane().add(lbl_title);

		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setFont(new Font("���� ����", Font.BOLD, 14));
		
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				DAO dao = new DAO();
				
				String movie = txt_movie.getText();
				//System.out.println(movie);
				
				
				int cnt = dao.deleteM(movie);
				System.out.println(cnt);
				if(cnt > 0) {
					System.out.println("��ȭ���� ����");
					P04_00_Adminpage.main(null);
					frame.dispose();
				}else {
					System.out.println("��ȭ���� ����");
					txt_movie.setText("");
					
				}
			}
		});
		
		btnNewButton.setBounds(86, 214, 97, 28);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_00_Adminpage.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(226, 214, 97, 28);
		frame.getContentPane().add(btnNewButton_1);

		JLabel lbl_movie = new JLabel("\uC601\uD654\uC81C\uBAA9");
		lbl_movie.setFont(new Font("���� ����", Font.BOLD, 13));
		lbl_movie.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_movie.setBounds(29, 144, 57, 29);
		frame.getContentPane().add(lbl_movie);

		txt_movie = new JTextField();
		txt_movie.setBounds(98, 139, 255, 39);
		frame.getContentPane().add(txt_movie);
		txt_movie.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("\uC601\uD654\uC0AD\uC81C");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 17));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(84, 34, 217, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
	}
}
