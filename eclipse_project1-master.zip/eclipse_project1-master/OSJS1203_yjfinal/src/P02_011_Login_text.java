import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class P02_011_Login_text {

	private JFrame frame;


	public P02_011_Login_text(String name) {
		initialize(name);
		frame.setVisible(true);
	
	}


	private void initialize(String name) {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbl_name = new JLabel(name); //���⿡ name ���� ������ â�� �̸� ������ �ʴ´�!!!
		lbl_name.setBackground(new Color(255, 255, 255));
		lbl_name.setFont(new Font("����", Font.PLAIN, 21));
		lbl_name.setBounds(14, 32, 397, 185);
		frame.getContentPane().add(lbl_name);
	}

}
