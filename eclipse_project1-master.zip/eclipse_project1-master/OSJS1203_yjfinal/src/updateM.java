import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import DAO.DAO;
import Model.InsertVO;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JTextField;

public class updateM {

	private JFrame frame;
	private JTable table;
	private JTable table_db;
	private ArrayList<InsertVO> list;
	private JTextField txt_title;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					updateM window = new updateM();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public updateM() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(400, 100, 927, 662);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JPanel panel = new JPanel();
		panel.setBounds(12, 10, 887, 603);
		frame.getContentPane().add(panel);
		panel.setLayout(null);

		JLabel lbl_add = new JLabel("\uC601 \uD654 \uCD94 \uAC00");
		lbl_add.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_add.setBounds(458, 10, 211, 34);
		panel.add(lbl_add);

		JScrollPane scr_cvs = new JScrollPane();
		JButton btn_call = new JButton("\uCD94 \uAC00 \uD558 \uAE30");
		btn_call.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// cvs ���̺� ����
				String url = "C:\\Users\\smhrd\\Desktop\\MovieAdd.csv";
				readFromCsv rd = new readFromCsv();
				List<List<String>> csvlist = rd.run(url, "euc-kr");

				String[] column = new String[csvlist.get(0).size()];
				for (int i = 0; i < csvlist.get(0).size(); i++) {
					column[i] = csvlist.get(0).get(i);
				}

				Object[][] data = new Object[csvlist.size()][csvlist.get(0).size()];

				for (int i = 0; i < csvlist.size() - 1; i++) {

					for (int j = 0; j < csvlist.get(0).size(); j++) {
						data[i][j] = csvlist.get(i + 1).get(j);
					}

				}

				for (int i = 0; i < data.length - 1; i++) {
					Object movie = data[i][0];
					Object genre = data[i][1];
					Object rating = data[i][2];

					DAO dao = new DAO();

					int result = dao.insertM(new InsertVO(movie, genre, rating));
				}

				System.out.println(data[0][0]);
				System.out.println(data[0][1]);
				System.out.println(data[0][2]);

				table = new JTable(data, column);
				scr_cvs.setViewportView(table);

			}
		});
		btn_call.setBounds(741, 16, 134, 23);
		panel.add(btn_call);

		scr_cvs.setBounds(458, 54, 417, 203);
		panel.add(scr_cvs);

		JLabel lbl_title_db = new JLabel("\uB370\uC774\uD130 \uB9AC\uC2A4\uD2B8");
		lbl_title_db.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_title_db.setBounds(12, 16, 211, 34);
		panel.add(lbl_title_db);

		JScrollPane scr_db = new JScrollPane();
		scr_db.setBounds(12, 54, 417, 538);
		panel.add(scr_db);

		JButton btn_refresh = new JButton("\uC0C8\uB85C\uACE0\uCE68");
		btn_refresh.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO daoM = new DAO();
				list = daoM.allSelectM();
				String[] columnM = { "Movie_title", "Genre", "Rating" };
				Object[][] dataM = new Object[list.size()][columnM.length];

				System.out.println(list.size());

				for (int i = 0; i < list.size(); i++) {
					dataM[i][0] = list.get(i).getMovie_title();
					dataM[i][1] = list.get(i).getGenre();
					dataM[i][2] = list.get(i).getRating();
				}

				for (int j = 0; j < dataM.length; j++) {
					for (int i = 0; i < dataM[j].length; i++) {
						System.out.println(dataM[j][i]);
					}
					System.out.println();
				}

				table_db = new JTable(dataM, columnM);
				scr_db.setViewportView(table_db);
			}
		});

		btn_refresh.setBounds(295, 22, 134, 23);
		panel.add(btn_refresh);

		JLabel lbl_title_1 = new JLabel("\uC601 \uD654 \uC0AD \uC81C");
		lbl_title_1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_title_1.setBounds(458, 341, 211, 34);
		panel.add(lbl_title_1);

		JButton btn_call_1 = new JButton("\uC0AD \uC81C \uD558 \uAE30");
		btn_call_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				String movie_title = txt_title.getText();

				InsertVO vo = new InsertVO(movie_title);

				DAO dao = new DAO();
				int result = dao.deleteM1(new InsertVO(movie_title));

			}
		});
		btn_call_1.setBounds(741, 347, 134, 23);
		panel.add(btn_call_1);

		JLabel lbl_title_1_1 = new JLabel("\uC601\uD654 \uC81C\uBAA9");
		lbl_title_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_title_1_1.setBounds(458, 407, 98, 34);
		panel.add(lbl_title_1_1);

		txt_title = new JTextField();
		txt_title.setBounds(553, 407, 322, 34);
		panel.add(txt_title);
		txt_title.setColumns(10);

		JButton btnNewButton = new JButton("\uB3CC\uC544\uAC00\uAE30");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_00_Adminpage.main(null);
				frame.dispose();
			}
		});
		btnNewButton.setBounds(744, 529, 114, 39);
		panel.add(btnNewButton);

	}
}
