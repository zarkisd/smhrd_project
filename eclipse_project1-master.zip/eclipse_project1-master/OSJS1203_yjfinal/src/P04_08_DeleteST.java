

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DAO.DAO;

public class P04_08_DeleteST {

	private JFrame frame;
	private JTextField txt_seat;
	private static String name;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P04_08_DeleteST window = new P04_08_DeleteST(name);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P04_08_DeleteST(String name) {
		initialize(name);
		frame.setVisible(true);
	}

	private void initialize(String name) {
		frame = new JFrame();
		frame.setBounds(400, 100, 467, 326);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lbl_title = new JLabel("\uC88C\uC11D\uC744 \uC0AD\uC81C \uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?"); // ���⿡ name ���� ������ â�� �̸� ������
																							// �ʴ´�!!!
		lbl_title.setFont(new Font("���� ����", Font.PLAIN, 17));
		lbl_title.setBounds(132, 75, 213, 46);
		frame.getContentPane().add(lbl_title);

		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				DAO dao = new DAO();
				
				String seat = txt_seat.getText();
				//System.out.println(movie);
				
				
				int cnt = dao.deleteST(seat);
				System.out.println(cnt);
				if(cnt > 0) {
					System.out.println("�¼����� ����");
					P04_00_Adminpage.main(null);
					frame.dispose();
				}else {
					System.out.println("�¼����� ����");
					txt_seat.setText("");
				}
			
			}
		});
		
		btnNewButton.setBounds(120, 220, 97, 29);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_00_Adminpage.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(229, 220, 97, 29);
		frame.getContentPane().add(btnNewButton_1);

		JLabel lbl_seat = new JLabel("\uC88C\uC11D");
		lbl_seat.setFont(new Font("���� ����", Font.BOLD, 14));
		lbl_seat.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_seat.setBounds(31, 155, 57, 29);
		frame.getContentPane().add(lbl_seat);

		txt_seat = new JTextField();
		txt_seat.setBounds(100, 147, 308, 46);
		frame.getContentPane().add(txt_seat);
		txt_seat.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("\uC88C\uC11D\uC0AD\uC81C");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(57, 36, 337, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
	}
}
