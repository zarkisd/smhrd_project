
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

public class P03_02_MovieInfo6 {

	private JFrame frame;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P03_02_MovieInfo6 window = new P03_02_MovieInfo6();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	
	
	public P03_02_MovieInfo6() {
		initialize();
	}


	private void initialize() {
		frame = new JFrame();
		frame.setBounds(500, 150, 683, 698);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 10, 667, 659);
		frame.getContentPane().add(panel);
		
		
		
		//���� ���� �ϴ� Ȩ��ư
		System.out.println(getClass().getResource("").getPath());
		String url6 = getClass().getResource("").getPath()+"home_home.png";		
		Image image6 = new ImageIcon(url6).getImage();				
		image6 = image6.getScaledInstance(30, 30, Image.SCALE_SMOOTH);
				
		//���� ���� �ϴ� ���Ź�ư
		System.out.println(getClass().getResource("").getPath());
		String url7 = getClass().getResource("").getPath()+"home_tiket1.png";		
		Image image7 = new ImageIcon(url7).getImage();				
		image7 = image7.getScaledInstance(30, 30, Image.SCALE_SMOOTH);

		//��ȭ���� �̹��� �ִ°�!
		System.out.println(getClass().getResource("").getPath());
		String url = getClass().getResource("").getPath()+"poster6.png";		
		Image image = new ImageIcon(url).getImage();				
		image = image.getScaledInstance(200, 250, Image.SCALE_SMOOTH);
		
		

		JButton btn_home = new JButton(new ImageIcon(image6));
		btn_home.setBounds(95, 565, 53, 39);
		btn_home.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//Ȩȭ������ �̵�
				P03_00_MainHomepage.main(null);
				frame.dispose();

			}
		});
		btn_home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel.setLayout(null);
		btn_home.setBackground(new Color(106, 90, 205));
		panel.add(btn_home);
		
		JButton btn_tiket1 = new JButton(new ImageIcon(image7));
		btn_tiket1.setBounds(184, 565, 53, 39);
		btn_tiket1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//�����ϱ� â���� �̵�
				P03_01_Booking.main(null);
				frame.dispose();

			}
		});
		btn_tiket1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_tiket1.setBackground(new Color(106, 90, 205));
		panel.add(btn_tiket1);
		
		JLabel lblNewLabel_1 = new JLabel("\uD648");
		lblNewLabel_1.setBounds(115, 614, 29, 15);
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 15));
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\uC608\uB9E4\uD558\uAE30");
		lblNewLabel_2.setBounds(184, 614, 71, 15);
		lblNewLabel_2.setFont(new Font("���� ����", Font.BOLD, 15));
		panel.add(lblNewLabel_2);
		
		
		//��ȭ���� �̹��� �ִ°�!
		JLabel lbl_Label_img = new JLabel(new ImageIcon(image));
		lbl_Label_img.setBounds(341, 69, 234, 255);
		panel.add(lbl_Label_img);
		
		JLabel lbl_txt1 = new JLabel("\uC601\uD654 \uC815\uBCF4");
		lbl_txt1.setBounds(95, 42, 90, 49);
		lbl_txt1.setFont(new Font("���� ����", Font.BOLD, 20));
		panel.add(lbl_txt1);
		
		JLabel lbl_info = new JLabel("\uC18C\uAC1C\uAE00");
		lbl_info.setBounds(95, 361, 57, 31);
		lbl_info.setFont(new Font("���� ����", Font.BOLD, 16));
		panel.add(lbl_info);
		
		JLabel lbl_title = new JLabel("\uC81C\uBAA9");
		lbl_title.setBounds(95, 101, 57, 31);
		lbl_title.setFont(new Font("���� ����", Font.BOLD, 16));
		panel.add(lbl_title);
		
		JLabel lbl_rating = new JLabel("\uB4F1\uAE09");
		lbl_rating.setBounds(95, 183, 57, 31);
		lbl_rating.setFont(new Font("���� ����", Font.BOLD, 16));
		panel.add(lbl_rating);
		
		JLabel lbl_runtime = new JLabel("\uB7EC\uB2DD\uD0C0\uC784");
		lbl_runtime.setBounds(95, 224, 90, 31);
		lbl_runtime.setFont(new Font("���� ����", Font.BOLD, 16));
		panel.add(lbl_runtime);
		
		JLabel lbl_direc = new JLabel("\uAC10\uB3C5");
		lbl_direc.setBounds(95, 265, 57, 31);
		lbl_direc.setFont(new Font("���� ����", Font.BOLD, 16));
		panel.add(lbl_direc);
		
		JLabel lbl_actor = new JLabel("(\uC8FC\uC5F0)\uBC30\uC6B0");
		lbl_actor.setBounds(95, 309, 90, 31);
		lbl_actor.setFont(new Font("���� ����", Font.BOLD, 16));
		panel.add(lbl_actor);
		
		JLabel lbl_genre = new JLabel("\uC7A5\uB974");
		lbl_genre.setBounds(95, 142, 57, 31);
		lbl_genre.setFont(new Font("���� ����", Font.BOLD, 16));
		panel.add(lbl_genre);
		
		String url0 = "C:\\Users\\smhrd\\Desktop\\MovieInfo.csv";
		List<List<String>> csvlist = readFromCsv.run(url0, "euc-kr");
		
		int num = 6;
		
		JLabel lbl_1 = new JLabel(csvlist.get(num).get(0));
		lbl_1.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_1.setBounds(180, 101, 210, 31);
		panel.add(lbl_1);
		
		JLabel lbl_2 = new JLabel(csvlist.get(num).get(1));
		lbl_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_2.setBounds(180, 142, 210, 31);
		panel.add(lbl_2);
		
		JLabel lbl_3 = new JLabel(csvlist.get(num).get(2));
		lbl_3.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_3.setBounds(180, 183, 210, 31);
		panel.add(lbl_3);
		
		JLabel lbl_4 = new JLabel(csvlist.get(num).get(3));
		lbl_4.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_4.setBounds(180, 224, 210, 31);
		panel.add(lbl_4);
		
		JLabel lbl_5 = new JLabel(csvlist.get(num).get(4));
		lbl_5.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_5.setBounds(180, 265, 210, 31);
		panel.add(lbl_5);
		
		JLabel lbl_6 = new JLabel(csvlist.get(num).get(5));
		lbl_6.setFont(new Font("���� ����", Font.PLAIN, 14));
		lbl_6.setBounds(180, 309, 210, 31);
		panel.add(lbl_6);
		
		JTextPane txtpnFdvd = new JTextPane();
		txtpnFdvd.setFont(new Font("���� ����", Font.PLAIN, 16));
		txtpnFdvd.setText(csvlist.get(num).get(6));
		txtpnFdvd.setBounds(178, 361, 423, 180);
		panel.add(txtpnFdvd);

		
	}
}
