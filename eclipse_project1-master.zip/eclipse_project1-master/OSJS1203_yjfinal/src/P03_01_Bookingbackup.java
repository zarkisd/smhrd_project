
import java.awt.Color;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.toedter.calendar.JCalendar;

import DAO.DAO;

public class P03_01_Bookingbackup {

	private JFrame frame;
	private JTextField txtA, txtB, txtC, txtD, txtE, txt_1, txt_2, txt_3;
	private JLabel lbl_image1, lblNewLabel, lblNewLabel_1_4, lblNewLabel_1_3, lblNewLabel_2, lblNewLabel_1_5,
			lblNewLabel_3, lblNewLabel_1_2, lblNewLabel_7, lblNewLabel_7_1, lblNewLabel_7_2, lblNewLabel_7_3,
			lbl_people, lbl_snack, lbl_money;
	private JButton btnNewButton, btn_image0_2, btnNewButton_5, btnNewButton_5_1, btnNewButton_5_2, btnNewButton_5_3,
			btnNewButton_5_4;
	boolean ch, ch1, ch2, ch3, ch4, ch5, ch6, ch7, ch8, ch9, ch10, ch11, ch12, ch13, ch14, ch15, ch16, ch17, ch18, ch19,
			ch20, ch21, ch22, ch23, ch24, ch25, ch26, ch27, ch28, ch29 = false;

	static int c = 0;
	// �¼� ���� ���߿� ���ð�
	String abc = "";
	// �ð� ���߿� ���ð�
	String time = "";
	// �����ݾ�
	int snackAmount = 0;
	// ��¥ �����Ұ�
	String date = "";
	// �¼� �迭
	private JButton btnNewButton_2, btnNewButton_2_1, btnNewButton_2_2, btnNewButton_2_3, btnNewButton_2_4,
			btnNewButton_2_5, btnNewButton_2_6, btnNewButton_2_1_1, btnNewButton_2_2_1, btnNewButton_2_3_1,
			btnNewButton_2_4_1, btnNewButton_2_5_1, btnNewButton_2_6_1, btnNewButton_2_1_1_1, btnNewButton_2_2_1_1,
			btnNewButton_2_3_1_1, btnNewButton_2_4_1_1, btnNewButton_2_5_1_1, btnNewButton_2_6_1_1,
			btnNewButton_2_1_1_1_1, btnNewButton_2_2_1_1_1, btnNewButton_2_3_1_1_1, btnNewButton_2_4_1_1_1,
			btnNewButton_2_5_1_1_1, btnNewButton_2_6_1_1_1, btnNewButton_2_1_1_1_1_1, btnNewButton_2_2_1_1_1_1,
			btnNewButton_2_3_1_1_1_1, btnNewButton_2_4_1_1_1_1, btnNewButton_2_5_1_1_1_1;

	;
	private String[] seat = { "A01", "A02", "A03", "A04", "A05", "A06", "B01", "B02", "B03", "B04", "B05", "B06", "C01",
			"C02", "C03", "C04", "C05", "C06", "D01", "D02", "D03", "D04", "D05", "D06", "E01", "E02", "E03", "E04",
			"E05", "E06" };
	// J��ư�迭
	private JButton[] btn = new JButton[30];

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P03_01_Bookingbackup window = new P03_01_Bookingbackup();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P03_01_Bookingbackup() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBounds(500, 150, 683, 728);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(12, 10, 643, 679);
		frame.getContentPane().add(tabbedPane);

		// image1 ��� ����
		System.out.println(getClass().getResource("").getPath());
		String url1 = getClass().getResource("").getPath() + "img1.png";

		Image image1 = new ImageIcon(url1).getImage();

		image1 = image1.getScaledInstance(440, 100, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// image2 ��� ����
		System.out.println(getClass().getResource("").getPath());
		String url2 = getClass().getResource("").getPath() + "img2.png";

		Image image2 = new ImageIcon(url2).getImage();

		image2 = image2.getScaledInstance(890, 100, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// �ο��¼� ������ư btn_image1 ���� , ����������ư
		System.out.println(getClass().getResource("").getPath());
		String url3 = getClass().getResource("").getPath() + "img_before.png";

		Image image3 = new ImageIcon(url3).getImage();

		image3 = image3.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// �ο��¼� ������ư btn_image2 ����
		System.out.println(getClass().getResource("").getPath());
		String url4 = getClass().getResource("").getPath() + "img_next.png";

		Image image4 = new ImageIcon(url4).getImage();

		image4 = image4.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ��¥�ð� ������ư btn_image0_1 ����
		System.out.println(getClass().getResource("").getPath());
		String url5 = getClass().getResource("").getPath() + "img_before.png";

		Image image5 = new ImageIcon(url5).getImage();

		image5 = image5.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ��¥�ð� ������ư btn_image0_1 ����
		System.out.println(getClass().getResource("").getPath());
		String url6 = getClass().getResource("").getPath() + "img_next.png";

		Image image6 = new ImageIcon(url6).getImage();

		image6 = image6.getScaledInstance(60, 60, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ����Ȯ�� ������ư btn_image5 ����
		System.out.println(getClass().getResource("").getPath());
		String url8 = getClass().getResource("").getPath() + "img_before.png";

		Image image8 = new ImageIcon(url8).getImage();

		image8 = image8.getScaledInstance(89, 100, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ù��° �� image1 ��� ����
		System.out.println(getClass().getResource("").getPath());
		String url9 = getClass().getResource("").getPath() + "img1.png";

		Image image9 = new ImageIcon(url9).getImage();

		image9 = image9.getScaledInstance(440, 100, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ù��° �� image2 ��� ����
		System.out.println(getClass().getResource("").getPath());
		String url10 = getClass().getResource("").getPath() + "img2.png";

		Image image10 = new ImageIcon(url10).getImage();

		image10 = image10.getScaledInstance(890, 100, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ������ �̹��� ���� 1
		System.out.println(getClass().getResource("").getPath());
		String url16 = getClass().getResource("").getPath() + "snack1.png";

		Image image16 = new ImageIcon(url16).getImage();

		image16 = image16.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ������ �̹��� ���� 2
		System.out.println(getClass().getResource("").getPath());
		String url17 = getClass().getResource("").getPath() + "snack2.png";

		Image image17 = new ImageIcon(url17).getImage();

		image17 = image17.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ������ �̹��� ���� 3
		System.out.println(getClass().getResource("").getPath());
		String url18 = getClass().getResource("").getPath() + "snack3.png";

		Image image18 = new ImageIcon(url18).getImage();

		image18 = image18.getScaledInstance(150, 150, Image.SCALE_SMOOTH);
		frame.getContentPane().setLayout(null);

		// ���� ���� �ϴ� Ȩ��ư
		System.out.println(getClass().getResource("").getPath());
		String url19 = getClass().getResource("").getPath() + "home_home.png";
		Image image19 = new ImageIcon(url19).getImage();
		image19 = image19.getScaledInstance(30, 30, Image.SCALE_SMOOTH);

		// ��Ű ũ�� ���� �̹���

		// �гο� �̹����� ��ưũ�� Ű��� --> ��¥ �� �ð� ���� �ǹ�ư
		String url11 = getClass().getResource("").getPath() + "txt4.png";
		Image image11 = new ImageIcon(url11).getImage();
		image11 = image11.getScaledInstance(90, 70, Image.SCALE_SMOOTH);

		// �гο� �̹����� ��ưũ�� Ű��� --> �ο� �� �¼� ���� �ǹ�ư
		String url12 = getClass().getResource("").getPath() + "txt5.png";
		Image image12 = new ImageIcon(url12).getImage();
		image12 = image12.getScaledInstance(90, 70, Image.SCALE_SMOOTH);

		// �гο� �̹����� ��ưũ�� Ű��� --> ���� �ǹ�ư
		String url13 = getClass().getResource("").getPath() + "txt6.png";
		Image image13 = new ImageIcon(url13).getImage();
		image13 = image13.getScaledInstance(90, 70, Image.SCALE_SMOOTH);

		// �гο� �̹����� ��ưũ�� Ű��� --> ���� �ǹ�ư
		String url14 = getClass().getResource("").getPath() + "txt7.png";
		Image image14 = new ImageIcon(url14).getImage();
		image14 = image14.getScaledInstance(90, 70, Image.SCALE_SMOOTH);

		// �гο� �̹����� ��ưũ�� Ű��� --> ����Ȯ�� �ǹ�ư
		String url15 = getClass().getResource("").getPath() + "txt8.png";
		Image image15 = new ImageIcon(url15).getImage();
		image15 = image15.getScaledInstance(90, 70, Image.SCALE_SMOOTH);

		JLabel label = new JLabel("");

		JLabel label_1 = new JLabel("");

		JLabel label_2 = new JLabel("");

		JLabel label_3 = new JLabel("");

		JLabel label_4 = new JLabel("");

		JLabel label_5 = new JLabel("");

		JLabel label_6 = new JLabel("");

		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("", new ImageIcon(image11), panel, null);
		panel.setLayout(null);

		JPanel panel_5 = new JPanel();
		panel_5.setBounds(322, 39, 304, 432);
		panel_5.setBackground(new Color(255, 255, 255));
		panel.add(panel_5);
		panel_5.setLayout(null);

		JLabel lblNewLabel_1 = new JLabel(" \uC2DC\uAC04 \uC120\uD0DD");
		lblNewLabel_1.setBounds(106, 10, 91, 29);
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 20));
		panel_5.add(lblNewLabel_1);

		// ��¥ �� �ð� ��� ���
		JLabel lbl_image2 = new JLabel(new ImageIcon(image9));
		lbl_image2.setBounds(115, 491, 409, 94);
		panel.add(lbl_image2);

		// ��¥ �� �ð� ��� �ϴ�
		JLabel lbl_image2_1 = new JLabel(new ImageIcon(image10));
		lbl_image2_1.setBounds(106, 490, 426, 95);
		panel.add(lbl_image2_1);
		// ��¥ �ð� //������ư �̹���
		btn_image0_2 = new JButton(new ImageIcon(image6));
		btn_image0_2.setBounds(529, 490, 97, 95);
		btn_image0_2.setBackground(new Color(255, 255, 255));
		btn_image0_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(1);
				DAO dao = new DAO();
				for (int i = 0; i < btn.length; i++) {
					if (dao.confirm(seat[i]) == 1) {
						btn[i].setBackground(new Color(128, 128, 128));
					}
				}

			}
		});
		btn_image0_2.setBorder(null);
		panel.add(btn_image0_2);

		JButton btn_home = new JButton(new ImageIcon(image19));
		btn_home.setBounds(27, 508, 53, 39);
		btn_home.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// Ȩȭ�� ��ư ������ Ȩ���� �Ѿ��
				P03_00_MainHomepage.main(null);
				frame.dispose();
			}
		});

		btn_home.setBackground(new Color(106, 90, 205));
		panel.add(btn_home);

		JLabel lblNewLabel = new JLabel("\uD648");
		lblNewLabel.setBounds(47, 557, 29, 15);
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 15));
		panel.add(lblNewLabel);

		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(12, 423, 298, 39);
		panel.add(lblNewLabel_2);

		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(255, 255, 255));
		panel_4.setBounds(12, 39, 304, 315);
		panel.add(panel_4);
		panel_4.setLayout(null);

		JLabel lblNewLabel_1_1_1 = new JLabel("\uB0A0\uC9DC \uC120\uD0DD");
		lblNewLabel_1_1_1.setBounds(98, 10, 81, 33);
		panel_4.add(lblNewLabel_1_1_1);
		lblNewLabel_1_1_1.setFont(new Font("���� ����", Font.BOLD, 20));

		JCalendar calendar = new JCalendar();
		calendar.setBounds(0, 53, 304, 262);
		panel_4.add(calendar);

		JButton btnNewButton_3 = new JButton("\uB0A0\uC9DC \uD655\uC778");
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				P03_00_MainHomepage pdd = new P03_00_MainHomepage();
				DateFormat df = new SimpleDateFormat("yy/MM/dd");
				lblNewLabel_2.setText(df.format(calendar.getDate()));
				date = String.valueOf(df.format(calendar.getDate()));
				// 1

				String text = dao.dateTime(date);
				btnNewButton_5_1.setText(text);
				// 2
				String text1 = dao.dateTime1(date);
				btnNewButton_5_2.setText(text1);
				// 3
				String text2 = dao.dateTime2(date);
				btnNewButton_5_3.setText(text2);
				// 4
//				String str3 = String.valueOf(df.format(calendar.getDate()));
				String text3 = dao.dateTime3(date);
				btnNewButton_5_4.setText(text3);

			}
		});
		btnNewButton_3.setBounds(12, 381, 97, 32);
		btnNewButton_3.setForeground(new Color(255, 255, 255));
		btnNewButton_3.setFont(new Font("���� ����", Font.BOLD, 12));
		btnNewButton_3.setBackground(new Color(106, 90, 205));
		panel.add(btnNewButton_3);

		btnNewButton_5_1 = new JButton("");
		btnNewButton_5_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				DAO dao = new DAO();
				DateFormat df = new SimpleDateFormat("yy/MM/dd");
				String str = String.valueOf(df.format(calendar.getDate()));
				String text = dao.dateTime(str);
				lblNewLabel_3.setText(text);
				time = text;
			}
		});
		btnNewButton_5_1.setBounds(41, 80, 227, 29);
		btnNewButton_5_1.setForeground(new Color(255, 255, 255));
		btnNewButton_5_1.setBackground(new Color(106, 90, 205));
		btnNewButton_5_1.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_5.add(btnNewButton_5_1);

		btnNewButton_5_2 = new JButton("");
		btnNewButton_5_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DAO dao = new DAO();
				DateFormat df = new SimpleDateFormat("yy/MM/dd");
				String str1 = String.valueOf(df.format(calendar.getDate()));
				String text1 = dao.dateTime1(str1);
				lblNewLabel_3.setText(text1);
				time = text1;
			}
		});
		btnNewButton_5_2.setBounds(41, 155, 227, 29);
		btnNewButton_5_2.setForeground(new Color(255, 255, 255));
		btnNewButton_5_2.setBackground(new Color(106, 90, 205));
		btnNewButton_5_2.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_5.add(btnNewButton_5_2);

		btnNewButton_5_3 = new JButton("");
		btnNewButton_5_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DAO dao = new DAO();
				DateFormat df = new SimpleDateFormat("yy/MM/dd");
				String str2 = String.valueOf(df.format(calendar.getDate()));
				String text2 = dao.dateTime2(str2);
				lblNewLabel_3.setText(text2);
				time = text2;
			}
		});
		btnNewButton_5_3.setBounds(41, 230, 227, 29);
		btnNewButton_5_3.setForeground(new Color(255, 255, 255));
		btnNewButton_5_3.setBackground(new Color(106, 90, 205));
		btnNewButton_5_3.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_5.add(btnNewButton_5_3);

		btnNewButton_5_4 = new JButton("");
		btnNewButton_5_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DAO dao = new DAO();
				DateFormat df = new SimpleDateFormat("yy/MM/dd");
				String str3 = String.valueOf(df.format(calendar.getDate()));
				String text3 = dao.dateTime3(str3);
				lblNewLabel_3.setText(text3);
				time = text3;
			}
		});
		btnNewButton_5_4.setBounds(41, 305, 227, 29);
		btnNewButton_5_4.setForeground(new Color(255, 255, 255));
		btnNewButton_5_4.setBackground(new Color(106, 90, 205));
		btnNewButton_5_4.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_5.add(btnNewButton_5_4);

		lblNewLabel_3 = new JLabel();
		lblNewLabel_3.setBounds(41, 338, 227, 73);
		panel_5.add(lblNewLabel_3);

		// �ο� �¼� ��
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("", new ImageIcon(image12), panel_1, null);
		panel_1.setLayout(null);

		JLabel lbl_Label_1 = new JLabel("\uC88C\uC11D \uC120\uD0DD");
		lbl_Label_1.setBounds(280, 30, 84, 42);
		lbl_Label_1.setFont(new Font("���� ����", Font.BOLD, 20));
		panel_1.add(lbl_Label_1);

		JLabel lbl_Label_2 = new JLabel("| SCREEN |");
		lbl_Label_2.setBounds(290, 70, 59, 15);
		lbl_Label_2.setFont(new Font("���� ����", Font.BOLD, 11));
		panel_1.add(lbl_Label_2);

		// 2��° �� �ο��¼� �ؿ� ��ܿ� �ִ¹��
		JLabel lbl_image1_1 = new JLabel(new ImageIcon(image1));
		lbl_image1_1.setBounds(103, 491, 432, 94);
		panel_1.add(lbl_image1_1);

		JLabel lbl_image1_2_1 = new JLabel(new ImageIcon(image10));
		lbl_image1_2_1.setBounds(103, 491, 432, 94);
		panel_1.add(lbl_image1_2_1);
		// ù��° ��¥�� �ð� �ؿ� ��ܿ� �ִ¹�� ��

		// �ο��¼� //������ư �̹���
		JButton btn_image1_1 = new JButton(new ImageIcon(image3));
		btn_image1_1.setBackground(new Color(255, 255, 255));
		btn_image1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(0);
			}
		});
		btn_image1_1.setBorder(null);// ��ư �׵θ� ���ִ� �ڵ�
		btn_image1_1.setBounds(12, 491, 93, 94);
		panel_1.add(btn_image1_1);
		// �ο��¼� //������ư �̹���
		JButton btn_image1_2 = new JButton(new ImageIcon(image4));
		btn_image1_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(2);
			}
		});
		btn_image1_2.setBorder(null); // ��ư �׵θ� ���ִ� �ڵ�
		btn_image1_2.setBackground(new Color(255, 255, 255));
		btn_image1_2.setBounds(533, 491, 93, 94);
		panel_1.add(btn_image1_2);

		txtA = new JTextField();
		txtA.setBounds(108, 133, 34, 22);
		txtA.setFont(new Font("���� ����", Font.BOLD, 12));
		txtA.setForeground(Color.WHITE);
		txtA.setBackground(Color.LIGHT_GRAY);
		txtA.setText("A");
		txtA.setHorizontalAlignment(SwingConstants.CENTER);
		panel_1.add(txtA);
		txtA.setColumns(10);

		btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setAlignmentY(Component.TOP_ALIGNMENT);
		btnNewButton.setBounds(524, 40, 17, 16);
		btnNewButton.setBackground(Color.WHITE);
		panel_1.add(btnNewButton);

		// ��ư ���� ���ϰ� ����� �ڵ�
		btnNewButton.setEnabled(false);
//				//��ư �׵θ� ���ִ� �ڵ� 
//				btnNewButton.setBorder(null);

		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.setEnabled(false);
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setBackground(new Color(120, 120, 120));
		btnNewButton_1.setAlignmentY(0.0f);
		btnNewButton_1.setBounds(524, 65, 17, 16);
		panel_1.add(btnNewButton_1);

		JButton btnNewButton_1_1 = new JButton("");
		btnNewButton_1_1.setEnabled(false);
		btnNewButton_1_1.setBorder(null);
		btnNewButton_1_1.setBackground(Color.RED);
		btnNewButton_1_1.setAlignmentY(0.0f);
		btnNewButton_1_1.setBounds(524, 91, 17, 16);
		panel_1.add(btnNewButton_1_1);

		txt_1 = new JTextField();
		txt_1.setFont(new Font("���� ����", Font.PLAIN, 14));
		txt_1.setText("\uC608\uB9E4\uAC00\uB2A5");
		txt_1.setBounds(545, 30, 70, 34);
		panel_1.add(txt_1);
		txt_1.setColumns(10);

		// textField�� �����ϰ� ����� ���
		// 1. ����� ���ش�
		txt_1.setOpaque(false);
		// 2. ��輱 ���ֱ�
		txt_1.setBorder(null);

		txt_2 = new JTextField();
		txt_2.setFont(new Font("���� ����", Font.PLAIN, 14));
		txt_2.setText("\uC608\uB9E4\uC644\uB8CC");
		txt_2.setOpaque(false);
		txt_2.setColumns(10);
		txt_2.setBorder(null);
		txt_2.setBounds(545, 52, 70, 42);
		panel_1.add(txt_2);

		txt_3 = new JTextField();
		txt_3.setFont(new Font("���� ����", Font.PLAIN, 14));
		txt_3.setText("\uC120\uD0DD\uC88C\uC11D");
		txt_3.setOpaque(false);
		txt_3.setColumns(10);
		txt_3.setBorder(null);
		txt_3.setBounds(545, 65, 70, 70);
		panel_1.add(txt_3);

		btnNewButton_2 = new JButton("1");
		btn[0] = btnNewButton_2;
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch) {
					btnNewButton_2.setBackground(new Color(255, 0, 0));
					ch = !ch;
					c++;
					abc += seat[0] + " ";
					dao.delivery("A01");
				} else {
					btnNewButton_2.setBackground(new Color(255, 255, 255));
					ch = !ch;
					c--;
					dao.Notdelivery("A01");
				}

			}
		});
		btnNewButton_2.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(158, 120, 47, 47);
		panel_1.add(btnNewButton_2);

		btnNewButton_2_1 = new JButton("2");
		btn[1] = btnNewButton_2_1;
		btnNewButton_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch1) {
					btnNewButton_2_1.setBackground(new Color(255, 0, 0));
					ch1 = !ch1;
					c++;
					abc += seat[1] + " ";
					dao.delivery("A02");
				} else {
					btnNewButton_2_1.setBackground(new Color(255, 255, 255));
					ch1 = !ch1;
					c--;
					abc.replace(seat[1], " ");
					dao.Notdelivery("A02");
				}

			}
		});
		btnNewButton_2_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_1.setBackground(Color.WHITE);
		btnNewButton_2_1.setBounds(216, 120, 47, 47);
		panel_1.add(btnNewButton_2_1);

		btnNewButton_2_2 = new JButton("3");
		btn[2] = btnNewButton_2_2;
		btnNewButton_2_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch2) {
					btnNewButton_2_2.setBackground(new Color(255, 0, 0));
					ch2 = !ch2;
					c++;
					abc += seat[2] + " ";
					dao.delivery("A03");
				} else {
					btnNewButton_2_2.setBackground(new Color(255, 255, 255));
					ch2 = !ch2;
					c--;
					abc.replace(seat[2], " ");
					dao.Notdelivery("A03");
				}

			}
		});
		btnNewButton_2_2.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_2.setBackground(Color.WHITE);
		btnNewButton_2_2.setBounds(275, 120, 47, 47);
		panel_1.add(btnNewButton_2_2);

		btnNewButton_2_3 = new JButton("4");
		btn[3] = btnNewButton_2_3;
		btnNewButton_2_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch3) {
					btnNewButton_2_3.setBackground(new Color(255, 0, 0));
					ch3 = !ch3;
					c++;
					abc += seat[3] + " ";
					dao.delivery("A04");
				} else {
					btnNewButton_2_3.setBackground(new Color(255, 255, 255));
					ch3 = !ch3;
					c--;
					abc.replace(seat[3], " ");
					dao.Notdelivery("A04");
				}

			}
		});
		btnNewButton_2_3.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_3.setBackground(Color.WHITE);
		btnNewButton_2_3.setBounds(335, 120, 47, 47);
		panel_1.add(btnNewButton_2_3);

		btnNewButton_2_4 = new JButton("5");
		btn[4] = btnNewButton_2_4;
		btnNewButton_2_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DAO dao = new DAO();
				if (!ch4) {
					btnNewButton_2_4.setBackground(new Color(255, 0, 0));
					ch4 = !ch4;
					c++;
					abc += seat[4] + " ";
					dao.delivery("A05");
				} else {
					btnNewButton_2_4.setBackground(new Color(255, 255, 255));
					ch4 = !ch4;
					c--;
					abc.replace(seat[4], " ");
					dao.Notdelivery("A05");
				}
			}
		});
		btnNewButton_2_4.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_4.setBackground(Color.WHITE);
		btnNewButton_2_4.setBounds(394, 121, 47, 47);
		panel_1.add(btnNewButton_2_4);

		btnNewButton_2_5 = new JButton("6");
		btn[5] = btnNewButton_2_5;
		btnNewButton_2_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DAO dao = new DAO();
				if (!ch5) {
					btnNewButton_2_5.setBackground(new Color(255, 0, 0));
					ch5 = !ch5;
					c++;
					abc += seat[5] + " ";
					dao.delivery("A06");
				} else {
					btnNewButton_2_5.setBackground(new Color(255, 255, 255));
					ch5 = !ch5;
					c--;
					abc.replace(seat[5], " ");
					dao.Notdelivery("A06");
				}
			}
		});
		btnNewButton_2_5.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_5.setBackground(Color.WHITE);
		btnNewButton_2_5.setBounds(455, 121, 47, 47);
		panel_1.add(btnNewButton_2_5);

		txtB = new JTextField();
		txtB.setText("B");
		txtB.setHorizontalAlignment(SwingConstants.CENTER);
		txtB.setForeground(Color.WHITE);
		txtB.setFont(new Font("���� ����", Font.BOLD, 12));
		txtB.setColumns(10);
		txtB.setBackground(Color.LIGHT_GRAY);
		txtB.setBounds(108, 206, 34, 22);
		panel_1.add(txtB);

		btnNewButton_2_6 = new JButton("1");
		btn[6] = btnNewButton_2_6;
		btnNewButton_2_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				btnNewButton_2_6.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
						DAO dao = new DAO();
						if (!ch6) {
							btnNewButton_2_6.setBackground(new Color(255, 0, 0));
							ch6 = !ch3;
							c++;
							abc += seat[6] + " ";
							dao.delivery("B01");
						} else {
							btnNewButton_2_6.setBackground(new Color(255, 255, 255));
							ch6 = !ch6;
							c--;
							abc.replace(seat[6], " ");
							dao.Notdelivery("B01");
						}
					}
				});
			}
		});
		btnNewButton_2_6.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_6.setBackground(Color.WHITE);
		btnNewButton_2_6.setBounds(158, 193, 47, 47);
		panel_1.add(btnNewButton_2_6);

		btnNewButton_2_1_1 = new JButton("2");
		btn[7] = btnNewButton_2_1_1;
		btnNewButton_2_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DAO dao = new DAO();
				if (!ch7) {
					btnNewButton_2_1_1.setBackground(new Color(255, 0, 0));
					ch7 = !ch7;
					c++;
					abc += seat[7] + " ";
					dao.delivery("B02");
				} else {
					btnNewButton_2_1_1.setBackground(new Color(255, 255, 255));
					ch7 = !ch7;
					c--;
					abc.replace(seat[7], " ");
					dao.Notdelivery("B02");
				}
			}
		});
		btnNewButton_2_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_1_1.setBackground(Color.WHITE);
		btnNewButton_2_1_1.setBounds(216, 193, 47, 47);
		panel_1.add(btnNewButton_2_1_1);

		btnNewButton_2_2_1 = new JButton("3");
		btn[8] = btnNewButton_2_2_1;
		btnNewButton_2_2_1.addMouseListener(new MouseAdapter() {

			@Override
			public void mouseClicked(MouseEvent e) {
				DAO dao = new DAO();
				if (!ch8) {
					btnNewButton_2_2_1.setBackground(new Color(255, 0, 0));
					ch8 = !ch8;
					c++;
					abc += seat[8] + " ";
					dao.delivery("B03");
				} else {
					btnNewButton_2_2_1.setBackground(new Color(255, 255, 255));
					ch8 = !ch8;
					c--;
					abc.replace(seat[8], " ");
					dao.Notdelivery("B03");
				}
			}

		});
		btnNewButton_2_2_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_2_1.setBackground(Color.WHITE);
		btnNewButton_2_2_1.setBounds(275, 193, 47, 47);
		panel_1.add(btnNewButton_2_2_1);

		btnNewButton_2_3_1 = new JButton("4");
		btn[9] = btnNewButton_2_3_1;
		btnNewButton_2_3_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch9) {
					btnNewButton_2_3_1.setBackground(new Color(255, 0, 0));
					ch9 = !ch9;
					c++;
					abc += seat[9] + " ";
					dao.delivery("B04");
				} else {
					btnNewButton_2_3_1.setBackground(new Color(255, 255, 255));
					ch9 = !ch9;
					c--;
					abc.replace(seat[9], " ");
					dao.Notdelivery("B04");
				}

			}
		});
		btnNewButton_2_3_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_3_1.setBackground(Color.WHITE);
		btnNewButton_2_3_1.setBounds(335, 193, 47, 47);
		panel_1.add(btnNewButton_2_3_1);

		btnNewButton_2_4_1 = new JButton("5");
		btn[10] = btnNewButton_2_4_1;
		btnNewButton_2_4_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch10) {
					btnNewButton_2_4_1.setBackground(new Color(255, 0, 0));
					ch10 = !ch10;
					c++;
					abc += seat[10] + " ";
					dao.delivery("B05");
				} else {
					btnNewButton_2_4_1.setBackground(new Color(255, 255, 255));
					ch10 = !ch10;
					c--;
					abc.replace(seat[10], " ");
					dao.Notdelivery("B05");
				}

			}
		});
		btnNewButton_2_4_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_4_1.setBackground(Color.WHITE);
		btnNewButton_2_4_1.setBounds(394, 194, 47, 47);
		panel_1.add(btnNewButton_2_4_1);

		btnNewButton_2_5_1 = new JButton("6");
		btn[11] = btnNewButton_2_5_1;
		btnNewButton_2_5_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch11) {
					btnNewButton_2_5_1.setBackground(new Color(255, 0, 0));
					ch11 = !ch11;
					c++;
					abc += seat[11] + " ";
					dao.delivery("B06");
				} else {
					btnNewButton_2_5_1.setBackground(new Color(255, 255, 255));
					ch11 = !ch11;
					c--;
					abc.replace(seat[11], " ");
					dao.Notdelivery("B06");
				}

			}
		});
		btnNewButton_2_5_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_5_1.setBackground(Color.WHITE);
		btnNewButton_2_5_1.setBounds(455, 194, 47, 47);
		panel_1.add(btnNewButton_2_5_1);

		txtC = new JTextField();
		txtC.setText("C");
		txtC.setHorizontalAlignment(SwingConstants.CENTER);
		txtC.setForeground(Color.WHITE);
		txtC.setFont(new Font("���� ����", Font.BOLD, 12));
		txtC.setColumns(10);
		txtC.setBackground(Color.LIGHT_GRAY);
		txtC.setBounds(108, 279, 34, 22);
		panel_1.add(txtC);

		btnNewButton_2_6_1 = new JButton("1");
		btn[12] = btnNewButton_2_6_1;
		btnNewButton_2_6_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch12) {
					btnNewButton_2_6_1.setBackground(new Color(255, 0, 0));
					ch12 = !ch12;
					c++;
					abc += seat[12] + " ";
					dao.delivery("C01");
				} else {
					btnNewButton_2_6_1.setBackground(new Color(255, 255, 255));
					ch12 = !ch12;
					c--;
					abc.replace(seat[12], " ");
					dao.Notdelivery("C01");
				}

			}
		});
		btnNewButton_2_6_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_6_1.setBackground(Color.WHITE);
		btnNewButton_2_6_1.setBounds(158, 266, 47, 47);
		panel_1.add(btnNewButton_2_6_1);

		btnNewButton_2_1_1_1 = new JButton("2");
		btn[13] = btnNewButton_2_1_1_1;
		btnNewButton_2_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch13) {
					btnNewButton_2_1_1_1.setBackground(new Color(255, 0, 0));
					ch13 = !ch13;
					c++;
					abc += seat[13] + " ";
					dao.delivery("C02");
				} else {
					btnNewButton_2_1_1_1.setBackground(new Color(255, 255, 255));
					ch13 = !ch13;
					c--;
					abc.replace(seat[13], " ");
					dao.Notdelivery("C02");
				}

			}
		});
		btnNewButton_2_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_1_1_1.setBounds(216, 266, 47, 47);
		panel_1.add(btnNewButton_2_1_1_1);

		btnNewButton_2_2_1_1 = new JButton("3");
		btn[14] = btnNewButton_2_2_1_1;
		btnNewButton_2_2_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch14) {
					btnNewButton_2_2_1_1.setBackground(new Color(255, 0, 0));
					ch14 = !ch14;
					c++;
					abc += seat[14] + " ";
					dao.delivery("C03");
				} else {
					btnNewButton_2_2_1_1.setBackground(new Color(255, 255, 255));
					ch14 = !ch14;
					c--;
					abc.replace(seat[14], " ");
					dao.Notdelivery("C03");
				}

			}
		});
		btnNewButton_2_2_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_2_1_1.setBackground(Color.WHITE);
		btnNewButton_2_2_1_1.setBounds(275, 266, 47, 47);
		panel_1.add(btnNewButton_2_2_1_1);

		btnNewButton_2_3_1_1 = new JButton("4");
		btn[15] = btnNewButton_2_3_1_1;
		btnNewButton_2_3_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch15) {
					btnNewButton_2_3_1_1.setBackground(new Color(255, 0, 0));
					ch15 = !ch15;
					c++;
					abc += seat[15] + " ";
					dao.delivery("C04");
				} else {
					btnNewButton_2_3_1_1.setBackground(new Color(255, 255, 255));
					ch15 = !ch15;
					c--;
					abc.replace(seat[15], " ");
					dao.Notdelivery("C04");
				}

			}
		});
		btnNewButton_2_3_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_3_1_1.setBackground(Color.WHITE);
		btnNewButton_2_3_1_1.setBounds(335, 266, 47, 47);
		panel_1.add(btnNewButton_2_3_1_1);

		btnNewButton_2_4_1_1 = new JButton("5");
		btn[16] = btnNewButton_2_4_1_1;
		btnNewButton_2_4_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch16) {
					btnNewButton_2_4_1_1.setBackground(new Color(255, 0, 0));
					ch16 = !ch16;
					c++;
					abc += seat[16] + " ";
					dao.delivery("C05");
				} else {
					btnNewButton_2_4_1_1.setBackground(new Color(255, 255, 255));
					ch16 = !ch16;
					c--;
					abc.replace(seat[16], " ");
					dao.Notdelivery("C05");
				}

			}
		});
		btnNewButton_2_4_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_4_1_1.setBackground(Color.WHITE);
		btnNewButton_2_4_1_1.setBounds(394, 267, 47, 47);
		panel_1.add(btnNewButton_2_4_1_1);

		btnNewButton_2_5_1_1 = new JButton("6");
		btn[17] = btnNewButton_2_5_1_1;
		btnNewButton_2_5_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch17) {
					btnNewButton_2_5_1_1.setBackground(new Color(255, 0, 0));
					ch17 = !ch17;
					c++;
					abc += seat[17] + " ";
					dao.delivery("C06");
				} else {
					btnNewButton_2_5_1_1.setBackground(new Color(255, 255, 255));
					ch17 = !ch17;
					c--;
					abc.replace(seat[17], " ");
					dao.Notdelivery("C06");
				}

			}
		});
		btnNewButton_2_5_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_5_1_1.setBackground(Color.WHITE);
		btnNewButton_2_5_1_1.setBounds(455, 267, 47, 47);
		panel_1.add(btnNewButton_2_5_1_1);

		txtD = new JTextField();
		txtD.setText("D");
		txtD.setHorizontalAlignment(SwingConstants.CENTER);
		txtD.setForeground(Color.WHITE);
		txtD.setFont(new Font("���� ����", Font.BOLD, 12));
		txtD.setColumns(10);
		txtD.setBackground(Color.LIGHT_GRAY);
		txtD.setBounds(108, 353, 34, 22);
		panel_1.add(txtD);

		btnNewButton_2_6_1_1 = new JButton("1");
		btn[18] = btnNewButton_2_6_1_1;
		btnNewButton_2_6_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch18) {
					btnNewButton_2_6_1_1.setBackground(new Color(255, 0, 0));
					ch18 = !ch18;
					c++;
					abc += seat[18] + " ";
					dao.delivery("D01");
				} else {
					btnNewButton_2_6_1_1.setBackground(new Color(255, 255, 255));
					ch18 = !ch18;
					c--;
					abc.replace(seat[18], " ");
					dao.Notdelivery("D01");
				}

			}
		});
		btnNewButton_2_6_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_6_1_1.setBackground(Color.WHITE);
		btnNewButton_2_6_1_1.setBounds(158, 340, 47, 47);
		panel_1.add(btnNewButton_2_6_1_1);

		btnNewButton_2_1_1_1_1 = new JButton("2");
		btn[19] = btnNewButton_2_1_1_1_1;
		btnNewButton_2_1_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch19) {
					btnNewButton_2_1_1_1_1.setBackground(new Color(255, 0, 0));
					ch19 = !ch19;
					c++;
					abc += seat[19] + " ";
					dao.delivery("D02");
				} else {
					btnNewButton_2_1_1_1_1.setBackground(new Color(255, 255, 255));
					ch19 = !ch19;
					c--;
					abc.replace(seat[19], " ");
					dao.Notdelivery("D02");
				}

			}
		});
		btnNewButton_2_1_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_1_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_1_1_1_1.setBounds(216, 340, 47, 47);
		panel_1.add(btnNewButton_2_1_1_1_1);

		btnNewButton_2_2_1_1_1 = new JButton("3");
		btn[20] = btnNewButton_2_2_1_1_1;
		btnNewButton_2_2_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch20) {
					btnNewButton_2_2_1_1_1.setBackground(new Color(255, 0, 0));
					ch20 = !ch20;
					c++;
					abc += seat[20] + " ";
					dao.delivery("D03");
				} else {
					btnNewButton_2_2_1_1_1.setBackground(new Color(255, 255, 255));
					ch20 = !ch20;
					c--;
					abc.replace(seat[20], " ");
					dao.Notdelivery("D03");
				}

			}
		});
		btnNewButton_2_2_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_2_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_2_1_1_1.setBounds(275, 340, 47, 47);
		panel_1.add(btnNewButton_2_2_1_1_1);

		btnNewButton_2_3_1_1_1 = new JButton("4");
		btn[21] = btnNewButton_2_3_1_1_1;
		btnNewButton_2_3_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch21) {
					btnNewButton_2_3_1_1_1.setBackground(new Color(255, 0, 0));
					ch21 = !ch21;
					c++;
					abc += seat[21] + " ";
					dao.delivery("D04");
				} else {
					btnNewButton_2_3_1_1_1.setBackground(new Color(255, 255, 255));
					ch21 = !ch21;
					c--;
					abc.replace(seat[21], " ");
					dao.Notdelivery("D04");
				}

			}
		});
		btnNewButton_2_3_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_3_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_3_1_1_1.setBounds(335, 340, 47, 47);
		panel_1.add(btnNewButton_2_3_1_1_1);

		btnNewButton_2_4_1_1_1 = new JButton("5");
		btn[22] = btnNewButton_2_4_1_1_1;
		btnNewButton_2_4_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch22) {
					btnNewButton_2_4_1_1_1.setBackground(new Color(255, 0, 0));
					ch22 = !ch22;
					c++;
					abc += seat[22] + " ";
					dao.delivery("D05");
				} else {
					btnNewButton_2_4_1_1_1.setBackground(new Color(255, 255, 255));
					ch22 = !ch22;
					c--;
					abc.replace(seat[22], " ");
					dao.Notdelivery("D05");
				}

			}
		});
		btnNewButton_2_4_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_4_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_4_1_1_1.setBounds(394, 341, 47, 47);
		panel_1.add(btnNewButton_2_4_1_1_1);

		btnNewButton_2_5_1_1_1 = new JButton("6");
		btn[23] = btnNewButton_2_5_1_1_1;
		btnNewButton_2_5_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch23) {
					btnNewButton_2_5_1_1_1.setBackground(new Color(255, 0, 0));
					ch23 = !ch23;
					c++;
					abc += seat[23] + " ";
					dao.delivery("D06");
				} else {
					btnNewButton_2_5_1_1_1.setBackground(new Color(255, 255, 255));
					ch23 = !ch23;
					c--;
					abc.replace(seat[23], " ");
					dao.Notdelivery("D06");
				}

			}
		});
		btnNewButton_2_5_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_5_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_5_1_1_1.setBounds(455, 341, 47, 47);
		panel_1.add(btnNewButton_2_5_1_1_1);

		txtE = new JTextField();
		txtE.setText("E");
		txtE.setHorizontalAlignment(SwingConstants.CENTER);
		txtE.setForeground(Color.WHITE);
		txtE.setFont(new Font("���� ����", Font.BOLD, 12));
		txtE.setColumns(10);
		txtE.setBackground(Color.LIGHT_GRAY);
		txtE.setBounds(108, 429, 34, 22);
		panel_1.add(txtE);

		btnNewButton_2_6_1_1_1 = new JButton("1");
		btn[24] = btnNewButton_2_6_1_1_1;
		btnNewButton_2_6_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch24) {
					btnNewButton_2_6_1_1_1.setBackground(new Color(255, 0, 0));
					ch24 = !ch24;
					c++;
					abc += seat[24] + " ";
					dao.delivery("E01");
				} else {
					btnNewButton_2_6_1_1_1.setBackground(new Color(255, 255, 255));
					ch24 = !ch24;
					c--;
					abc.replace(seat[24], " ");
					dao.Notdelivery("E01");
				}

			}
		});
		btnNewButton_2_6_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_6_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_6_1_1_1.setBounds(158, 416, 47, 47);
		panel_1.add(btnNewButton_2_6_1_1_1);

		btnNewButton_2_1_1_1_1_1 = new JButton("2");
		btn[25] = btnNewButton_2_1_1_1_1_1;
		btnNewButton_2_1_1_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch25) {
					btnNewButton_2_1_1_1_1_1.setBackground(new Color(255, 0, 0));
					ch25 = !ch25;
					c++;
					abc += seat[25] + " ";
					dao.delivery("E02");
				} else {
					btnNewButton_2_1_1_1_1_1.setBackground(new Color(255, 255, 255));
					ch25 = !ch25;
					c--;
					abc.replace(seat[25], " ");
					dao.Notdelivery("E02");
				}

			}
		});
		btnNewButton_2_1_1_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_1_1_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_1_1_1_1_1.setBounds(216, 416, 47, 47);
		panel_1.add(btnNewButton_2_1_1_1_1_1);

		btnNewButton_2_2_1_1_1_1 = new JButton("3");
		btn[26] = btnNewButton_2_2_1_1_1_1;
		btnNewButton_2_2_1_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch26) {
					btnNewButton_2_2_1_1_1_1.setBackground(new Color(255, 0, 0));
					ch26 = !ch26;
					c++;
					abc += seat[26] + " ";
					dao.delivery("E03");
				} else {
					btnNewButton_2_2_1_1_1_1.setBackground(new Color(255, 255, 255));
					ch26 = !ch26;
					c--;
					abc.replace(seat[26], " ");
					dao.Notdelivery("E03");
				}

			}
		});
		btnNewButton_2_2_1_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_2_1_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_2_1_1_1_1.setBounds(275, 416, 47, 47);
		panel_1.add(btnNewButton_2_2_1_1_1_1);

		btnNewButton_2_3_1_1_1_1 = new JButton("4");
		btn[27] = btnNewButton_2_3_1_1_1_1;
		btnNewButton_2_3_1_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch27) {
					btnNewButton_2_3_1_1_1_1.setBackground(new Color(255, 0, 0));
					ch27 = !ch27;
					c++;
					abc += seat[27] + " ";
					dao.delivery("E04");
				} else {
					btnNewButton_2_3_1_1_1_1.setBackground(new Color(255, 255, 255));
					ch27 = !ch27;
					c--;
					abc.replace(seat[27], " ");
					dao.Notdelivery("E04");
				}

			}
		});
		btnNewButton_2_3_1_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_3_1_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_3_1_1_1_1.setBounds(335, 416, 47, 47);
		panel_1.add(btnNewButton_2_3_1_1_1_1);

		btnNewButton_2_4_1_1_1_1 = new JButton("5");
		btn[28] = btnNewButton_2_4_1_1_1_1;
		btnNewButton_2_4_1_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch28) {
					btnNewButton_2_4_1_1_1_1.setBackground(new Color(255, 0, 0));
					ch28 = !ch28;
					c++;
					abc += seat[28] + " ";
					dao.delivery("E05");
				} else {
					btnNewButton_2_4_1_1_1_1.setBackground(new Color(255, 255, 255));
					ch28 = !ch28;
					c--;
					abc.replace(seat[28], " ");
					dao.Notdelivery("E05");
				}

			}
		});
		btnNewButton_2_4_1_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_4_1_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_4_1_1_1_1.setBounds(394, 417, 47, 47);
		panel_1.add(btnNewButton_2_4_1_1_1_1);

		btnNewButton_2_5_1_1_1_1 = new JButton("6");
		btn[29] = btnNewButton_2_5_1_1_1_1;
		btnNewButton_2_5_1_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2_5_1_1_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();
				if (!ch29) {
					btnNewButton_2_5_1_1_1_1.setBackground(new Color(255, 0, 0));
					ch29 = !ch29;
					c++;
					abc += seat[29] + " ";
					dao.delivery("E06");
				} else {
					btnNewButton_2_5_1_1_1_1.setBackground(new Color(255, 255, 255));
					ch29 = !ch29;
					c--;
					abc.replace(seat[29], " ");
					dao.Notdelivery("E06");
				}

			}
		});
		btnNewButton_2_5_1_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 12));
		btnNewButton_2_5_1_1_1_1.setBackground(Color.WHITE);
		btnNewButton_2_5_1_1_1_1.setBounds(455, 417, 47, 47);
		panel_1.add(btnNewButton_2_5_1_1_1_1);

		// ���� ���� �ǹ�ư
		JPanel panel_3_1 = new JPanel();
		panel_3_1.setBackground(new Color(255, 255, 255));
		panel_3_1.setLayout(null);
		tabbedPane.addTab("", new ImageIcon(image13), panel_3_1, null);

		JPanel panel_7_1 = new JPanel();
		panel_7_1.setLayout(null);
		panel_7_1.setBackground(new Color(255, 99, 71));
		panel_7_1.setBounds(0, 0, 638, 135);
		panel_3_1.add(panel_7_1);

		JLabel lblNewLabel_5_2 = new JLabel("\uC2A4\uB0B5\uCF54\uB108");
		lblNewLabel_5_2.setForeground(Color.WHITE);
		lblNewLabel_5_2.setFont(new Font("���� ����", Font.BOLD, 27));
		lblNewLabel_5_2.setBounds(264, 39, 123, 53);
		panel_7_1.add(lblNewLabel_5_2);
		JPanel panel_8_1 = new JPanel();
		panel_8_1.setBackground(new Color(255, 248, 220));
		panel_8_1.setBounds(0, 134, 638, 451);
		panel_3_1.add(panel_8_1);
		panel_8_1.setLayout(null);

		// ���� �̹��� �ִ°�
		JLabel lbl_snack1 = new JLabel(new ImageIcon(image16));
		lbl_snack1.setBounds(40, 47, 176, 189);
		panel_8_1.add(lbl_snack1);

		JLabel lbl_snack2 = new JLabel(new ImageIcon(image17));
		lbl_snack2.setBounds(228, 47, 176, 189);
		panel_8_1.add(lbl_snack2);

		JLabel lbl_snack3 = new JLabel(new ImageIcon(image18));
		lbl_snack3.setBounds(413, 47, 176, 189);
		panel_8_1.add(lbl_snack3);

		JButton btnNewButton_4 = new JButton("\uD31D\uCF58");
		btnNewButton_4.setBounds(88, 235, 97, 29);
		btnNewButton_4.setBackground(new Color(255, 99, 71));
		btnNewButton_4.setForeground(new Color(255, 255, 255));
		btnNewButton_4.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_8_1.add(btnNewButton_4);

		JButton btnNewButton_4_1 = new JButton("\uD56B\uB3C4\uADF8");
		btnNewButton_4_1.setBounds(273, 235, 97, 29);
		btnNewButton_4_1.setBackground(new Color(255, 99, 71));
		btnNewButton_4_1.setForeground(new Color(255, 255, 255));
		btnNewButton_4_1.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_8_1.add(btnNewButton_4_1);

		JButton btnNewButton_4_1_1 = new JButton("\uC0CC\uB4DC\uC704\uCE58");
		btnNewButton_4_1_1.setBounds(461, 235, 97, 29);
		btnNewButton_4_1_1.setBackground(new Color(255, 99, 71));
		btnNewButton_4_1_1.setForeground(new Color(255, 255, 255));
		btnNewButton_4_1_1.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_8_1.add(btnNewButton_4_1_1);

		JCheckBox chckbxNewCheckBox = new JCheckBox("6,500");
		chckbxNewCheckBox.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.out.println("1");
				snackAmount += 6500;
			}
		});
		chckbxNewCheckBox.setBackground(new Color(255, 248, 220));
		chckbxNewCheckBox.setFont(new Font("���� ����", Font.BOLD, 16));
		chckbxNewCheckBox.setBounds(101, 276, 91, 23);
		panel_8_1.add(chckbxNewCheckBox);

		JCheckBox chckbxNewCheckBox_1 = new JCheckBox("3,500");
		chckbxNewCheckBox_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				snackAmount += 3500;
				System.out.println("2");
			}
		});
		chckbxNewCheckBox_1.setBackground(new Color(255, 248, 220));
		chckbxNewCheckBox_1.setFont(new Font("���� ����", Font.BOLD, 16));
		chckbxNewCheckBox_1.setBounds(289, 276, 115, 23);
		panel_8_1.add(chckbxNewCheckBox_1);

		JCheckBox chckbxNewCheckBox_1_1 = new JCheckBox("5,500");
		chckbxNewCheckBox_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				System.out.println("3");
				snackAmount += 5500;
			}
		});
		chckbxNewCheckBox_1_1.setBackground(new Color(255, 248, 220));
		chckbxNewCheckBox_1_1.setFont(new Font("���� ����", Font.BOLD, 16));
		chckbxNewCheckBox_1_1.setBounds(479, 276, 97, 23);
		panel_8_1.add(chckbxNewCheckBox_1_1);

		// �����ڳ� ������ư
		JButton btn_image3_2 = new JButton(new ImageIcon(image4));
		btn_image3_2.setBounds(535, 362, 91, 79);
		panel_8_1.add(btn_image3_2);
		btn_image3_2.setBackground(new Color(255, 248, 220));
		btn_image3_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				lbl_people.setText(c + "");
				String price = c * 13000 + snackAmount + "";
				String snacktext = snackAmount + "";
				lbl_snack.setText(snacktext);
				lbl_money.setText(price);
				tabbedPane.setSelectedIndex(3);
			}
		});
		btn_image3_2.setBorder(null);// ��ư �׵θ� ���ִ� �ڵ�

		// �����ڳ� ������ư
		JButton btn_image3_1 = new JButton(new ImageIcon(image3));
		btn_image3_1.setBounds(12, 362, 91, 79);
		panel_8_1.add(btn_image3_1);
		btn_image3_1.setBackground(new Color(255, 248, 220));
		btn_image3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ����â �Ѿ��
				tabbedPane.setSelectedIndex(1);
			}
		});

		btn_image3_1.setBorder(null);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("", new ImageIcon(image14), panel_2, null);

		// ���� ���̺� ���� ��ư
		JButton btn_image4_1 = new JButton(new ImageIcon(image3));
		btn_image4_1.setBounds(12, 490, 97, 95);
		btn_image4_1.setBackground(new Color(255, 255, 255));
		btn_image4_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// ����â���� �Ѿ��
				tabbedPane.setSelectedIndex(2);
			}
		});
		panel_2.setLayout(null);
		btn_image4_1.setBorder(null);
		panel_2.add(btn_image4_1);

		// ���� ���̺� ���� ��ư
		JButton btn_image4_2 = new JButton(new ImageIcon(image4));
		btn_image4_2.setBounds(533, 490, 93, 94);
		btn_image4_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tabbedPane.setSelectedIndex(4);
				P03_00_MainHomepage p03main = new P03_00_MainHomepage();
				String text = c + "";
				String[] aaa = abc.split(" ");
				Arrays.sort(aaa);
				String text1 = Arrays.toString(aaa);
				String text2 = time;
				String text3 = p03main.movieTitle;
				System.out.println(text3);
				lblNewLabel_7_2.setText(text);// �ż�
				lblNewLabel_7_1.setText(text1);// �¼�
				lblNewLabel_7_3.setText(text2);// �ð�
				lblNewLabel_7.setText(text3);
				// ����

			}
		});
		btn_image4_2.setBorder(null); // ��ư �׵θ� ���ִ� �ڵ�
		btn_image4_2.setBackground(new Color(255, 255, 255));
		panel_2.add(btn_image4_2);

		JButton btnNewButton_6 = new JButton("\uACB0\uC81C\uD655\uC778\uBC84\uD2BC");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JOptionPane.showMessageDialog(null, "���� ����", "���� ����â", JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton_6.setBackground(new Color(106, 90, 205));
		btnNewButton_6.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_6.setForeground(new Color(255, 255, 255));
		btnNewButton_6.setBounds(513, 442, 113, 38);
		panel_2.add(btnNewButton_6);

		JLabel lblNewLabel_4_3_1 = new JLabel("\uC778\uC6D0");
		lblNewLabel_4_3_1.setBounds(67, 52, 57, 15);
		panel_2.add(lblNewLabel_4_3_1);

		lbl_people = new JLabel("");
		lbl_people.setBounds(154, 52, 57, 15);
		panel_2.add(lbl_people);

		lbl_snack = new JLabel("");
		lbl_snack.setBounds(154, 105, 57, 15);
		panel_2.add(lbl_snack);

		lbl_money = new JLabel("");
		lbl_money.setBounds(154, 412, 57, 15);
		panel_2.add(lbl_money);

		JLabel lblNewLabel_4_3_1_1 = new JLabel("\uC2A4\uB0B5");
		lblNewLabel_4_3_1_1.setBounds(67, 105, 57, 15);
		panel_2.add(lblNewLabel_4_3_1_1);

		JLabel lblNewLabel_4_3_1_1_1 = new JLabel("\uCD1D \uACB0\uC81C \uAE08\uC561");
		lblNewLabel_4_3_1_1_1.setBounds(31, 412, 93, 15);
		panel_2.add(lblNewLabel_4_3_1_1_1);

		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("", new ImageIcon(image15), panel_3, null);
		panel_3.setLayout(null);

		JPanel panel_7 = new JPanel();
		panel_7.setBackground(new Color(106, 90, 205));
		panel_7.setBounds(0, 0, 638, 145);
		panel_3.add(panel_7);
		panel_7.setLayout(null);

		JLabel lblNewLabel_5 = new JLabel("\uC608\uB9E4\uAC00 \uC644\uB8CC \uB418\uC5C8\uC2B5\uB2C8\uB2E4!");
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setFont(new Font("���� ����", Font.BOLD, 22));
		lblNewLabel_5.setBounds(204, 50, 240, 43);
		panel_7.add(lblNewLabel_5);

		JButton btn_next_1_1 = new JButton("\uC608\uB9E4 \uCDE8\uC18C");
		btn_next_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DAO dao = new DAO();
				P03_00_MainHomepage.main(null);
				frame.dispose();
				String[] aaa = abc.split(" ");
				Arrays.sort(aaa);
				for (int i = 0; i < aaa.length; i++) {
					if (dao.confirm(aaa[i]) == 1) {
						dao.Notdelivery(aaa[i]);
					}
				}
			}
		});
		btn_next_1_1.setBounds(32, 506, 121, 42);
		panel_3.add(btn_next_1_1);
		btn_next_1_1.setBackground(new Color(106, 90, 205));
		btn_next_1_1.setForeground(new Color(255, 255, 255));
		btn_next_1_1.setFont(new Font("���� ����", Font.PLAIN, 16));

		JButton btn_next_1_1_1 = new JButton("\uD655\uC778 \uC644\uB8CC");
		btn_next_1_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				DAO dao = new DAO();

				P03_00_MainHomepage p03main = new P03_00_MainHomepage();
				String text2 = time;
				String text3 = p03main.movieTitle;
				int price = c * 13000 + snackAmount;
				for (int j = 0; j < seat.length; j++) {
					if (dao.confirm(seat[j]) == 1) {
						dao.reserve(P02_01_Login.login_id, text3, date, text2, seat[j], price);
					}
				}
				System.out.println(snackAmount);
				System.out.println("���� ����");

				JOptionPane.showMessageDialog(null, "��ſ� ���� �ǽʽÿ�", "���� Ȯ��â", JOptionPane.INFORMATION_MESSAGE);

				frame.dispose();
				P01_MainOpen.main(null);
			}
		});
		btn_next_1_1_1.setForeground(Color.WHITE);
		btn_next_1_1_1.setFont(new Font("���� ����", Font.PLAIN, 16));
		btn_next_1_1_1.setBackground(new Color(106, 90, 205));
		btn_next_1_1_1.setBounds(486, 506, 121, 42);
		panel_3.add(btn_next_1_1_1);

		JPanel panel_8 = new JPanel();
		panel_8.setBackground(new Color(255, 255, 255));
		panel_8.setBounds(0, 144, 638, 441);
		panel_3.add(panel_8);
		panel_8.setLayout(null);

		JLabel lblNewLabel_4_1 = new JLabel("\u2714\uC81C\uBAA9");
		lblNewLabel_4_1.setFont(new Font("���� ����", Font.BOLD, 16));
		lblNewLabel_4_1.setBounds(91, 159, 92, 24);
		panel_8.add(lblNewLabel_4_1);

		JLabel lblNewLabel_4_1_1 = new JLabel("\u2714\uC88C\uC11D\uC815\uBCF4");
		lblNewLabel_4_1_1.setFont(new Font("���� ����", Font.BOLD, 16));
		lblNewLabel_4_1_1.setBounds(91, 232, 92, 24);
		panel_8.add(lblNewLabel_4_1_1);

		JLabel lblNewLabel_4_1_2 = new JLabel("\u2714\uC0C1\uC601\uC2DC\uAC04");
		lblNewLabel_4_1_2.setFont(new Font("���� ����", Font.BOLD, 16));
		lblNewLabel_4_1_2.setBounds(395, 159, 92, 24);
		panel_8.add(lblNewLabel_4_1_2);

		JLabel lblNewLabel_4_2 = new JLabel("\u2714\uB9E4\uC218");
		lblNewLabel_4_2.setFont(new Font("���� ����", Font.BOLD, 16));
		lblNewLabel_4_2.setBounds(395, 84, 92, 24);
		panel_8.add(lblNewLabel_4_2);

		lblNewLabel_7 = new JLabel();
		lblNewLabel_7.setBounds(218, 165, 116, 18);
		panel_8.add(lblNewLabel_7);

		lblNewLabel_7_1 = new JLabel();
		lblNewLabel_7_1.setBounds(218, 232, 116, 18);
		panel_8.add(lblNewLabel_7_1);

		lblNewLabel_7_2 = new JLabel();
		lblNewLabel_7_2.setBounds(499, 90, 116, 18);
		panel_8.add(lblNewLabel_7_2);

		lblNewLabel_7_3 = new JLabel();
		lblNewLabel_7_3.setBounds(499, 159, 116, 18);
		panel_8.add(lblNewLabel_7_3);

	}
}
