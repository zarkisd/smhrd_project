
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.Box;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.SwingConstants;

import DAO.DAO;

import javax.swing.JTextPane;
import javax.swing.JEditorPane;
import javax.swing.SpringLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.Icon;
import javax.swing.JComboBox;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class P03_00_MainHomepage {

	private JFrame frame;
	private JButton btn_book3;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JLabel lblNewLabel_1_3, lbl_randomNumber_1;
	public static String movieTitle;
	private int magicNum = 3;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P03_00_MainHomepage window = new P03_00_MainHomepage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P03_00_MainHomepage() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(255, 255, 255));
		frame.setBackground(new Color(255, 255, 255));
		frame.setBounds(500, 150, 683, 698); // ��üâ ũ��!
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// ������� �̹���, 1
		System.out.println(getClass().getResource("").getPath());
		String url = getClass().getResource("").getPath() + "poster1.png";
		Image image = new ImageIcon(url).getImage();
		image = image.getScaledInstance(200, 250, Image.SCALE_SMOOTH);

		// ������� �̹���,2
		System.out.println(getClass().getResource("").getPath());
		String url1 = getClass().getResource("").getPath() + "poster2.png";
		Image image1 = new ImageIcon(url1).getImage();
		image1 = image1.getScaledInstance(200, 250, Image.SCALE_SMOOTH);

		// ������� �̹���,3
		System.out.println(getClass().getResource("").getPath());
		String url2 = getClass().getResource("").getPath() + "poster3.png";
		Image image2 = new ImageIcon(url2).getImage();
		image2 = image2.getScaledInstance(200, 250, Image.SCALE_SMOOTH);

		// �гο� �̹����� ��ưũ�� Ű��� --> ��������ǹ�ư
		String url3 = getClass().getResource("").getPath() + "txt1.png";
		Image image3 = new ImageIcon(url3).getImage();
		image3 = image3.getScaledInstance(90, 70, Image.SCALE_SMOOTH);

		// �гο� �̹����� ��ưũ�� Ű��� --> �󿵿������ǹ�ư
		String url4 = getClass().getResource("").getPath() + "txt2.png";
		Image image4 = new ImageIcon(url4).getImage();
		image4 = image4.getScaledInstance(90, 70, Image.SCALE_SMOOTH);

		// �гο� �̹����� ��ưũ�� Ű��� --> ���������ǹ�ư
		String url5 = getClass().getResource("").getPath() + "txt3.png";
		Image image5 = new ImageIcon(url5).getImage();
		image5 = image5.getScaledInstance(90, 70, Image.SCALE_SMOOTH);

		// ���� ���� �ϴ� Ȩ��ư
		System.out.println(getClass().getResource("").getPath());
		String url6 = getClass().getResource("").getPath() + "home_home.png";
		Image image6 = new ImageIcon(url6).getImage();
		image6 = image6.getScaledInstance(30, 30, Image.SCALE_SMOOTH);

		// ���� ���� �ϴ� ���Ź�ư
		System.out.println(getClass().getResource("").getPath());
		String url7 = getClass().getResource("").getPath() + "home_tiket1.png";
		Image image7 = new ImageIcon(url7).getImage();
		image7 = image7.getScaledInstance(30, 30, Image.SCALE_SMOOTH);

		// ���� ���� �ϴ� ���� ���Ź�ư
		System.out.println(getClass().getResource("").getPath());
		String url8 = getClass().getResource("").getPath() + "home_tiket1.png";
		Image image8 = new ImageIcon(url8).getImage();
		image8 = image8.getScaledInstance(30, 30, Image.SCALE_SMOOTH);

		// ���� ���� �ϴ� ���� ��ư
		System.out.println(getClass().getResource("").getPath());
		String url9 = getClass().getResource("").getPath() + "home_delicous.png";
		Image image9 = new ImageIcon(url9).getImage();
		image9 = image9.getScaledInstance(30, 30, Image.SCALE_SMOOTH);

		// ���� ���� �ϴ� ���� ��ư
		System.out.println(getClass().getResource("").getPath());
		String url10 = getClass().getResource("").getPath() + "home_mypage.png";
		Image image10 = new ImageIcon(url10).getImage();
		image10 = image10.getScaledInstance(30, 30, Image.SCALE_SMOOTH);

		// �󿵿����� ������ ù��° �̹��� �κ�
		System.out.println(getClass().getResource("").getPath());
		String url11 = getClass().getResource("").getPath() + "poster4.png";
		Image image11 = new ImageIcon(url11).getImage();
		image11 = image11.getScaledInstance(200, 250, Image.SCALE_SMOOTH);

		// �󿵿����� ������ �ι�° �̹��� �κ�
		System.out.println(getClass().getResource("").getPath());
		String url12 = getClass().getResource("").getPath() + "poster5.png";
		Image image12 = new ImageIcon(url12).getImage();
		image12 = image12.getScaledInstance(200, 250, Image.SCALE_SMOOTH);

		// �󿵿����� ������ ����° �̹��� �κ�
		System.out.println(getClass().getResource("").getPath());
		String url13 = getClass().getResource("").getPath() + "poster6.png";
		Image image13 = new ImageIcon(url13).getImage();
		image13 = image13.getScaledInstance(200, 250, Image.SCALE_SMOOTH);

		// ��ȭ ���� ���Ű� �������� �̹���
		System.out.println(getClass().getResource("").getPath());
		String url14 = getClass().getResource("").getPath() + "randomimg.png";
		Image image14 = new ImageIcon(url14).getImage();
		image14 = image14.getScaledInstance(500, 500, Image.SCALE_SMOOTH);

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBackground(new Color(255, 255, 255));
		tabbedPane.setBounds(12, 10, 943, 639);
		frame.getContentPane().add(tabbedPane);

		// �гο� �̹����� ��ưũ�� Ű��� --> ��������ǹ�ư
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("", new ImageIcon(image3), panel_1, null);
		panel_1.setLayout(null);// �̰� �� �־����!
		// �гο� �̹����� ��ưũ�� Ű��� --> ��������ǹ�ư ��

		// �гο� �̹����� ��ưũ�� Ű��� --> �󿵿������ǹ�ư
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("", new ImageIcon(image4), panel_2, null);
		panel_2.setLayout(null);// �̰� �� �־����!
		// �гο� �̹����� ��ưũ�� Ű��� --> �󿵿������ǹ�ư

		// �гο� �̹����� ��ưũ�� Ű��� --> ���������ǹ�ư
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(255, 255, 255));
		tabbedPane.addTab("", new ImageIcon(image5), panel_3, null);

		// ���� ���� �ϴ� Ȩ��ư
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setBackground(new Color(255, 255, 255));
		panel_2_1.setBounds(0, 0, 662, 575);
		panel_1.add(panel_2_1);
		panel_2_1.setLayout(null);

		// ���� ���� ���ڵ�
		JLabel lbl_Label_1 = new JLabel(new ImageIcon(image));
		lbl_Label_1.setBounds(22, 49, 206, 261);
		panel_2_1.add(lbl_Label_1);

		JLabel lbl_Label_2 = new JLabel(new ImageIcon(image1));
		lbl_Label_2.setBounds(229, 49, 210, 261);
		panel_2_1.add(lbl_Label_2);

		JLabel lbl_Label_3 = new JLabel(new ImageIcon(image2));
		lbl_Label_3.setBounds(441, 49, 195, 261);
		panel_2_1.add(lbl_Label_3);

		JButton btnNewButton = new JButton("\uC0C1\uC138\uC815\uBCF4");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// �������� �Ѿ��
				P03_02_MovieInfo1.main(null);
				frame.dispose();
			}
		});
		btnNewButton.setBounds(32, 307, 89, 36);
		btnNewButton.setBackground(new Color(65, 105, 225));
		btnNewButton.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton.setForeground(new Color(255, 255, 255));
		panel_2_1.add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uC608\uB9E4\uD558\uAE30");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				movieTitle = lblNewLabel_1_3.getText();
				System.out.println(movieTitle);
				P03_01_Booking.main(null);
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(123, 307, 95, 36);
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_1.setBackground(new Color(255, 0, 0));
		panel_2_1.add(btnNewButton_1);

		JButton btnNewButton_2 = new JButton("\uC0C1\uC138\uC815\uBCF4");

		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_02_MovieInfo2.main(null);
				frame.dispose();
			}
		});
		btnNewButton_2.setBounds(240, 307, 89, 36);
		btnNewButton_2.setForeground(Color.WHITE);
		btnNewButton_2.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_2.setBackground(new Color(65, 105, 225));
		panel_2_1.add(btnNewButton_2);

		JButton btnNewButton_1_1 = new JButton("\uC608\uB9E4\uD558\uAE30");
		btnNewButton_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_01_Booking.main(null);
				frame.dispose();
			}
		});
		btnNewButton_1_1.setBounds(331, 307, 95, 36);
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_1_1.setBackground(Color.RED);
		panel_2_1.add(btnNewButton_1_1);

		JButton btnNewButton_3 = new JButton("\uC0C1\uC138\uC815\uBCF4");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_02_MovieInfo3.main(null);
				frame.dispose();
			}
		});
		btnNewButton_3.setBounds(451, 307, 89, 36);
		btnNewButton_3.setForeground(Color.WHITE);
		btnNewButton_3.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_3.setBackground(new Color(65, 105, 225));
		panel_2_1.add(btnNewButton_3);

		JButton btnNewButton_1_2 = new JButton("\uC608\uB9E4\uD558\uAE30");
		btnNewButton_1_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_01_Booking.main(null);
				frame.dispose();
			}
		});
		btnNewButton_1_2.setBounds(542, 307, 94, 36);
		btnNewButton_1_2.setForeground(Color.WHITE);
		btnNewButton_1_2.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_1_2.setBackground(Color.RED);
		panel_2_1.add(btnNewButton_1_2);

		textField = new JTextField();
		textField.setBounds(42, 353, 20, 21);
		textField.setFont(new Font("���� ����", Font.BOLD, 12));
		textField.setForeground(new Color(255, 255, 255));
		textField.setBackground(new Color(30, 144, 255));
		textField.setText("12");
		panel_2_1.add(textField);
		textField.setColumns(10);

		textField_1 = new JTextField();
		textField_1.setBounds(250, 353, 20, 21);
		textField_1.setText("12");
		textField_1.setForeground(Color.WHITE);
		textField_1.setFont(new Font("���� ����", Font.BOLD, 12));
		textField_1.setColumns(10);
		textField_1.setBackground(new Color(30, 144, 255));
		panel_2_1.add(textField_1);

		textField_2 = new JTextField();
		textField_2.setBounds(461, 353, 20, 21);
		textField_2.setText("12");
		textField_2.setForeground(Color.WHITE);
		textField_2.setFont(new Font("���� ����", Font.BOLD, 12));
		textField_2.setColumns(10);
		textField_2.setBackground(new Color(30, 144, 255));
		panel_2_1.add(textField_2);

		JLabel lblNewLabel_1 = new JLabel("\uC2A4\uD30C\uC774\uB354\uB9E8 \uD648\uCEE4\uBC0D");
		lblNewLabel_1.setBounds(482, 353, 113, 21);
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_2_1.add(lblNewLabel_1);

		JLabel lblNewLabel_1_2 = new JLabel("\uB178\uD2B8\uBD81");
		lblNewLabel_1_2.setBounds(271, 353, 47, 21);
		lblNewLabel_1_2.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_2_1.add(lblNewLabel_1_2);

		lblNewLabel_1_3 = new JLabel("\uC774\uC6C3\uC0AC\uCD0C");
		lblNewLabel_1_3.setBounds(63, 353, 113, 21);
		lblNewLabel_1_3.setFont(new Font("���� ����", Font.BOLD, 13));
		panel_2_1.add(lblNewLabel_1_3);

		// ���� ���� �ϴ� Ȩ��ư ������
		JButton btn_home = new JButton(new ImageIcon(image6));
		btn_home.setBounds(81, 464, 53, 39);
		btn_home.setBackground(new Color(106, 90, 205));
		btn_home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				P03_00_MainHomepage.main(null);
				frame.dispose();
			}
		});
		panel_2_1.add(btn_home);

		// ���� ���� �ϴ� ���� ������
		JButton btn_tiket1 = new JButton(new ImageIcon(image7));
		btn_tiket1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// �����ϱ���
				P03_01_Booking.main(null);
				frame.dispose();
			}
		});
		btn_tiket1.setBounds(233, 464, 53, 39);
		btn_tiket1.setBackground(new Color(106, 90, 205));
		btn_tiket1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel_2_1.add(btn_tiket1);

		// ���� ���� �ϴ� �������� ������
		JButton btn_tiket2 = new JButton(new ImageIcon(image8));
		btn_tiket2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ���������ϱ� �Ǵ����� �̵�
				tabbedPane.setSelectedIndex(2);
			}
		});
		btn_tiket2.setBounds(378, 464, 53, 39);
		btn_tiket2.setBackground(new Color(106, 90, 205));
		btn_tiket2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_tiket2.setFont(new Font("���� ����", Font.BOLD, 10));
		panel_2_1.add(btn_tiket2);

		// ���� ���� �ϴ� ���������� ������
		JButton btn_mypage = new JButton(new ImageIcon(image10));
		btn_mypage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ���������� ��ư ������ ���������� �����ϱ�
				P03_05_Mypage.main(null);
				frame.dispose();
			}
		});
		btn_mypage.setBounds(524, 464, 53, 39);
		btn_mypage.setBackground(new Color(106, 90, 205));
		btn_mypage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		panel_2_1.add(btn_mypage);

		JLabel lblNewLabel = new JLabel("\uD648");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel.setBounds(101, 513, 29, 15);
		panel_2_1.add(lblNewLabel);

		JLabel lblNewLabel_2 = new JLabel("\uC608\uB9E4\uD558\uAE30");
		lblNewLabel_2.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_2.setBounds(231, 513, 71, 15);
		panel_2_1.add(lblNewLabel_2);

		JLabel lblNewLabel_2_1 = new JLabel("\uB79C\uB364 \uC608\uB9E4\uD558\uAE30");
		lblNewLabel_2_1.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_2_1.setBounds(365, 513, 102, 15);
		panel_2_1.add(lblNewLabel_2_1);

		JLabel lblNewLabel_2_1_1_1 = new JLabel("\uB9C8\uC774\uD398\uC774\uC9C0");
		lblNewLabel_2_1_1_1.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_2_1_1_1.setBounds(515, 513, 71, 15);
		panel_2_1.add(lblNewLabel_2_1_1_1);

		// �󿵿����� ù��° �������̹����κ�
		JLabel lbl_Label_1_1 = new JLabel(new ImageIcon(image11));
		lbl_Label_1_1.setText("");
		lbl_Label_1_1.setBounds(23, 55, 206, 261);
		panel_2.add(lbl_Label_1_1);

		// �� ������ ��ĩ�� ������ �Ǻκ�
		JButton btnNewButton_4 = new JButton("\uC0C1\uC138\uC815\uBCF4");
		btnNewButton_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_02_MovieInfo4.main(null);
				frame.dispose();
			}
		});
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_4.setForeground(Color.WHITE);
		btnNewButton_4.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_4.setBackground(new Color(65, 105, 225));
		btnNewButton_4.setBounds(33, 313, 89, 36);
		panel_2.add(btnNewButton_4);

		JButton btnNewButton_5 = new JButton("\uC608\uB9E4\uD558\uAE30");
		btnNewButton_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_01_Booking.main(null);
				frame.dispose();
			}
		});
		btnNewButton_5.setForeground(Color.WHITE);
		btnNewButton_5.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_5.setBackground(Color.RED);
		btnNewButton_5.setBounds(124, 313, 95, 36);
		panel_2.add(btnNewButton_5);

		textField_3 = new JTextField();
		textField_3.setText("12");
		textField_3.setForeground(Color.WHITE);
		textField_3.setFont(new Font("���� ����", Font.BOLD, 12));
		textField_3.setColumns(10);
		textField_3.setBackground(new Color(30, 144, 255));
		textField_3.setBounds(43, 359, 20, 21);
		panel_2.add(textField_3);

		JLabel lblNewLabel_1_3_1 = new JLabel("\uC794\uCE6B\uB0A0");
		lblNewLabel_1_3_1.setFont(new Font("���� ����", Font.BOLD, 13));
		lblNewLabel_1_3_1.setBounds(64, 359, 113, 21);
		panel_2.add(lblNewLabel_1_3_1);

		// �󿵿����� �ι�° �������̹����κ�
		JLabel lbl_Label_2_1 = new JLabel(new ImageIcon(image12));
		lbl_Label_2_1.setBounds(230, 55, 210, 261);
		panel_2.add(lbl_Label_2_1);

		JButton btnNewButton_6 = new JButton("\uC0C1\uC138\uC815\uBCF4");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_02_MovieInfo5.main(null);
				frame.dispose();
			}
		});
		btnNewButton_6.setForeground(Color.WHITE);
		btnNewButton_6.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_6.setBackground(new Color(65, 105, 225));
		btnNewButton_6.setBounds(241, 313, 89, 36);
		panel_2.add(btnNewButton_6);

		JButton btnNewButton_7 = new JButton("\uC608\uB9E4\uD558\uAE30");
		btnNewButton_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_01_Booking.main(null);
				frame.dispose();
			}
		});
		btnNewButton_7.setForeground(Color.WHITE);
		btnNewButton_7.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_7.setBackground(Color.RED);
		btnNewButton_7.setBounds(332, 313, 95, 36);
		panel_2.add(btnNewButton_7);

		textField_4 = new JTextField();
		textField_4.setText("19");
		textField_4.setForeground(Color.WHITE);
		textField_4.setFont(new Font("���� ����", Font.BOLD, 12));
		textField_4.setColumns(10);
		textField_4.setBackground(new Color(255, 0, 0));
		textField_4.setBounds(251, 359, 20, 21);
		panel_2.add(textField_4);

		JLabel lblNewLabel_1_2_1 = new JLabel("\uC6A9\uB8E8\uAC01 : \uBE44\uC815\uB3C4\uC2DC");
		lblNewLabel_1_2_1.setFont(new Font("���� ����", Font.BOLD, 13));
		lblNewLabel_1_2_1.setBounds(272, 359, 155, 21);
		panel_2.add(lblNewLabel_1_2_1);

		// �󿵿����� ����° �������̹����κ�
		JLabel lbl_Label_3_1 = new JLabel(new ImageIcon(image13));
		lbl_Label_3_1.setBounds(442, 55, 195, 261);
		panel_2.add(lbl_Label_3_1);

		JButton btnNewButton_8 = new JButton("\uC0C1\uC138\uC815\uBCF4");
		btnNewButton_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_02_MovieInfo6.main(null);
				frame.dispose();
			}
		});
		btnNewButton_8.setForeground(Color.WHITE);
		btnNewButton_8.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_8.setBackground(new Color(65, 105, 225));
		btnNewButton_8.setBounds(452, 313, 89, 36);
		panel_2.add(btnNewButton_8);

		JButton btnNewButton_9 = new JButton("\uC608\uB9E4\uD558\uAE30");
		btnNewButton_9.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P03_01_Booking.main(null);
				frame.dispose();
			}
		});
		btnNewButton_9.setForeground(Color.WHITE);
		btnNewButton_9.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_9.setBackground(Color.RED);
		btnNewButton_9.setBounds(543, 313, 94, 36);
		panel_2.add(btnNewButton_9);

		textField_5 = new JTextField();
		textField_5.setText("12");
		textField_5.setForeground(Color.WHITE);
		textField_5.setFont(new Font("���� ����", Font.BOLD, 12));
		textField_5.setColumns(10);
		textField_5.setBackground(new Color(30, 144, 255));
		textField_5.setBounds(462, 359, 20, 21);
		panel_2.add(textField_5);

		JLabel lblNewLabel_1_1 = new JLabel("\uC0B0\uD2F0\uC544\uACE0\uC758 \uD770 \uC9C0\uD321\uC774");
		lblNewLabel_1_1.setFont(new Font("���� ����", Font.BOLD, 13));
		lblNewLabel_1_1.setBounds(483, 359, 154, 21);
		panel_2.add(lblNewLabel_1_1);

		JButton btn_home_1 = new JButton(new ImageIcon(image6));
		btn_home_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				P03_00_MainHomepage.main(null);
				frame.dispose();
			}
		});
		btn_home_1.setBackground(new Color(106, 90, 205));
		btn_home_1.setBounds(83, 467, 53, 39);
		panel_2.add(btn_home_1);

		JButton btn_tiket1_1 = new JButton(new ImageIcon(image7));
		btn_tiket1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// �󿵿����� ���� ��ư ������ ����â���� �Ѿ��
				P03_01_Booking.main(null);
				frame.dispose();

			}
		});
		btn_tiket1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_tiket1_1.setBackground(new Color(106, 90, 205));
		btn_tiket1_1.setBounds(233, 467, 53, 39);
		panel_2.add(btn_tiket1_1);

		JButton btn_tiket2_1 = new JButton(new ImageIcon(image8));
		btn_tiket2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ���������� �̵��ϱ�
				tabbedPane.setSelectedIndex(2);
			}
		});
		btn_tiket2_1.setFont(new Font("���� ����", Font.BOLD, 10));
		btn_tiket2_1.setBackground(new Color(106, 90, 205));
		btn_tiket2_1.setBounds(376, 467, 53, 39);
		panel_2.add(btn_tiket2_1);

		JButton btn_mypage_1 = new JButton(new ImageIcon(image10));
		btn_mypage_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// �󿵿����� ���������� ������ �̵��ϱ�
				P03_05_Mypage.main(null);
				frame.dispose();
			}
		});
		btn_mypage_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_mypage_1.setBackground(new Color(106, 90, 205));
		btn_mypage_1.setBounds(527, 467, 53, 39);
		panel_2.add(btn_mypage_1);

		JLabel lblNewLabel_2_1_1_1_1 = new JLabel("\uB9C8\uC774\uD398\uC774\uC9C0");
		lblNewLabel_2_1_1_1_1.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_2_1_1_1_1.setBounds(522, 516, 71, 15);
		panel_2.add(lblNewLabel_2_1_1_1_1);

		JLabel lblNewLabel_2_1_2 = new JLabel("\uB79C\uB364 \uC608\uB9E4\uD558\uAE30");
		lblNewLabel_2_1_2.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_2_1_2.setBounds(360, 516, 102, 15);
		panel_2.add(lblNewLabel_2_1_2);

		JLabel lblNewLabel_2_2 = new JLabel("\uC608\uB9E4\uD558\uAE30");
		lblNewLabel_2_2.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_2_2.setBounds(230, 516, 71, 15);
		panel_2.add(lblNewLabel_2_2);

		JLabel lblNewLabel_3 = new JLabel("\uD648");
		lblNewLabel_3.setFont(new Font("���� ����", Font.BOLD, 15));
		lblNewLabel_3.setBounds(103, 516, 27, 15);
		panel_2.add(lblNewLabel_3);
		panel_3.setLayout(null);

		// ���� ���� �������� �̹��� ������
		JLabel lblNewLabel_4 = new JLabel(new ImageIcon(image14));
		lblNewLabel_4.setBounds(107, 25, 450, 336);
		panel_3.add(lblNewLabel_4);

		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(92, 365, 219, 47);
		comboBox.setBackground(new Color(255, 255, 255));
		comboBox.setEnabled(true);
		panel_3.add(comboBox);
		String[] genre = { "DRAMA", "COMEDY", "ACTION", "HORROR", "DOCU", "SCIFI", "CHILD" };
		comboBox.setModel(new DefaultComboBoxModel(genre));

		JLabel lbl_randomNumber = new JLabel("");
		lbl_randomNumber.setBounds(535, 365, 57, 47);
		lbl_randomNumber.setFont(new Font("���� ����", Font.BOLD, 18));
		panel_3.add(lbl_randomNumber);

		lbl_randomNumber_1 = new JLabel("");
		lbl_randomNumber_1.setBounds(263, 455, 351, 33);
		lbl_randomNumber_1.setFont(new Font("���� ����", Font.BOLD, 20));
		panel_3.add(lbl_randomNumber_1);

		JButton btn_randombtn = new JButton("\uD074\uB9AD~!");

		btn_randombtn.setBounds(329, 361, 124, 51);
		btn_randombtn.setForeground(new Color(255, 255, 255));
		btn_randombtn.setFont(new Font("���� ����", Font.BOLD, 18));
		btn_randombtn.setBackground(new Color(106, 90, 205));
		btn_randombtn.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {

				DAO dao = new DAO();
				int num = 0;
				lbl_randomNumber.setText(magicNum + "");
				magicNum--;
				if (magicNum == -1) {
					JOptionPane.showMessageDialog(null, "��ȸ�� ���� �����", "��ȸ ����â", JOptionPane.ERROR_MESSAGE);
					P03_01_Booking.main(null);
					frame.dispose();
				}

				if (comboBox.getSelectedItem().equals("DRAMA")) {
					num = (int) (Math.random() * dao.countOfMovie() + 1);
					String text1 = dao.genreMovie("DRAMA", num);
					lbl_randomNumber_1.setText(text1);
				} else if (comboBox.getSelectedItem().equals("COMEDY")) {
					num = (int) (Math.random() * dao.countOfMovie() + 1);
					String text1 = dao.genreMovie("COMEDY", num);
					lbl_randomNumber_1.setText(text1);
				} else if (comboBox.getSelectedItem().equals("ACTION")) {
					num = (int) (Math.random() * dao.countOfMovie() + 1);
					String text1 = dao.genreMovie("ACTION", num);
					lbl_randomNumber_1.setText(text1);
				} else if (comboBox.getSelectedItem().equals("HORROR")) {
					num = (int) (Math.random() * dao.countOfMovie() + 1);
					String text1 = dao.genreMovie("HORROR", num);
					lbl_randomNumber_1.setText(text1);
				} else if (comboBox.getSelectedItem().equals("DOCU")) {
					num = (int) (Math.random() * dao.countOfMovie() + 1);
					String text1 = dao.genreMovie("DOCU", num);
					lbl_randomNumber_1.setText(text1);
				} else if (comboBox.getSelectedItem().equals("SCIFI")) {
					num = (int) (Math.random() * dao.countOfMovie() + 1);
					String text1 = dao.genreMovie("SCIFI", num);
					lbl_randomNumber_1.setText(text1);
				} else if (comboBox.getSelectedItem().equals("CHILD")) {
					num = (int) (Math.random() * dao.countOfMovie() + 1);
					String text1 = dao.genreMovie("CHILD", num);
					lbl_randomNumber_1.setText(text1);
				}

			}
		});

		panel_3.add(btn_randombtn);

		JLabel lblNewLabel_5 = new JLabel("\uB0A8\uC740\uD69F\uC218");
		lblNewLabel_5.setBounds(467, 372, 68, 32);
		lblNewLabel_5.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_3.add(lblNewLabel_5);

		JLabel lblNewLabel_5_1 = new JLabel("\uB79C\uB364 \uC601\uD654 \uC81C\uBAA9");
		lblNewLabel_5_1.setBounds(143, 455, 110, 32);
		lblNewLabel_5_1.setFont(new Font("���� ����", Font.BOLD, 15));
		panel_3.add(lblNewLabel_5_1);

		JButton btnNewButton_10 = new JButton(
				"\uB79C\uB364 \uC601\uD654 \uC0C1\uC138\uC815\uBCF4 \uBCF4\uB7EC\uAC00\uAE30");

		btnNewButton_10.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				// ���� ��ȭ ������â���� �̵���Ű��!
				movieTitle = lbl_randomNumber_1.getText();
				P03_02_MovieInfo1.main(null);
				frame.dispose();
			}
		});
		btnNewButton_10.setForeground(Color.WHITE);
		btnNewButton_10.setFont(new Font("���� ����", Font.BOLD, 14));
		btnNewButton_10.setBackground(new Color(65, 105, 225));
		btnNewButton_10.setBounds(425, 517, 211, 36);
		panel_3.add(btnNewButton_10);

	}
}
