
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;

import DAO.DAO;
import Model.InsertVO;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;

public class P04_03_InsertM {

	private JFrame frame;
	private JTextField txt_movie_title;
	private JTextField txt_genre;
	private JTextField txt_rating;
	private JButton btn_inset;
	private JButton check_id;
	private JButton btnNewButton;


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P04_03_InsertM window = new P04_03_InsertM();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public P04_03_InsertM() {
		initialize();
	}


	private void initialize() {
		frame = new JFrame();
		frame.setBounds(400, 100, 547, 392);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lbl_title = new JLabel("\uC601\uD654\uCD94\uAC00");
		lbl_title.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_title.setFont(new Font("���� ����", Font.BOLD, 17));
		lbl_title.setBounds(84, 28, 325, 63);
		frame.getContentPane().add(lbl_title);
		
		JLabel lbl_movie_title = new JLabel("\uC601\uD654\uC81C\uBAA9");
		lbl_movie_title.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_movie_title.setFont(new Font("���� ����", Font.BOLD, 13));
		lbl_movie_title.setBounds(38, 100, 74, 41);
		frame.getContentPane().add(lbl_movie_title);
		
		txt_movie_title = new JTextField();
		txt_movie_title.setBounds(124, 101, 272, 33);
		frame.getContentPane().add(txt_movie_title);
		txt_movie_title.setColumns(10);
		
		JLabel lbl_genre = new JLabel("\uC7A5\uB974");
		lbl_genre.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_genre.setFont(new Font("���� ����", Font.BOLD, 13));
		lbl_genre.setBounds(48, 155, 48, 41);
		frame.getContentPane().add(lbl_genre);
		
		txt_genre = new JTextField();
		txt_genre.setColumns(10);
		txt_genre.setBounds(124, 153, 272, 33);
		frame.getContentPane().add(txt_genre);
		
		JLabel lbl_rating = new JLabel("\uB4F1\uAE09");
		lbl_rating.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_rating.setFont(new Font("���� ����", Font.BOLD, 13));
		lbl_rating.setBounds(38, 210, 74, 41);
		frame.getContentPane().add(lbl_rating);
		
		txt_rating = new JTextField();
		txt_rating.setColumns(10);
		txt_rating.setBounds(124, 210, 272, 33);
		frame.getContentPane().add(txt_rating);
		
		btn_inset = new JButton("\uC601\uD654\uCD94\uAC00\uD558\uAE30");
		btn_inset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btn_inset.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				//textfield�� �ִ� ���� ������ �ͼ� ������ ����
				String movie_title = txt_movie_title.getText();
				String genre = txt_genre.getText();
				String rating = txt_rating.getText();
												
				// age --> ������
				//Integer.parseInt
				//InsertVO vo = new InsertVO(id, pw, name, age);
				// - > vo�� ������� �ʱ� ������ ������ �������� �ο�x
				// DAO Ŭ������ ������ �ִ� insert ����� ���!
				// 1. DAOŬ���� �ҷ�����
				DAO dao = new DAO();
				// 2. DAOŬ���� insert��� ����
				// result - > ������ ���� ���� ����
				int result = dao.insertM(new InsertVO(movie_title, genre, rating));
					
				if(result > 0) {
					
					//�˾�â ����!
					JOptionPane.showMessageDialog(null, "��ȭ�߰� ����!", "��ȭ�߰� ����â",JOptionPane.INFORMATION_MESSAGE);
					// showMessageDialog(�θ�������Ʈ, ����� �޼���, ����, ������)	
					P04_00_Adminpage.main(null);
					frame.dispose();	
					
				}else {
					JOptionPane.showMessageDialog(null, "��ȭ�߰� ����!", "��ȭ�߰� ����â", JOptionPane.ERROR_MESSAGE);
					txt_movie_title.setText("");
					txt_genre.setText("");
					txt_rating.setText("");
				}
				
//				System.out.println(id + pw + name + age);				
				//ex01Login���� �̵�
				
				
				//���� â�� �ݱ�
				
				
				
			}
		});
		btn_inset.setFont(new Font("���� ����", Font.BOLD, 14));
		btn_inset.setBounds(88, 284, 236, 33);
		frame.getContentPane().add(btn_inset);
		
		
		
		check_id = new JButton("\uC911\uBCF5\uD655\uC778");
		check_id.setFont(new Font("���� ����", Font.PLAIN, 12));
		check_id.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String title = txt_movie_title.getText();
				DAO daoM = new DAO();
				String resulttitle = daoM.deduplicationM(title);
				
				if(resulttitle.equals(title)) {
					JOptionPane.showMessageDialog(null, "�ߺ�!","�ߺ�â",JOptionPane.INFORMATION_MESSAGE); 
					
				}else {
					JOptionPane.showMessageDialog(null, "�ߺ��� �ƴմϴ�!", "�ߺ�â", JOptionPane.INFORMATION_MESSAGE);
					
				}
			}
		});
		check_id.setBounds(408, 101, 97, 28);
		frame.getContentPane().add(check_id);
		
		btnNewButton = new JButton("\uCDE8\uC18C");
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 14));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_00_Adminpage.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(336, 284, 97, 33);
		frame.getContentPane().add(btnNewButton);
		


	}
}
