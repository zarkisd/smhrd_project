

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DAO.DAO;

public class P04_06_DeleteC {

	private JFrame frame;
	private JTextField txt_cinema_name;
	private static String name;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P04_06_DeleteC window = new P04_06_DeleteC(name);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P04_06_DeleteC(String name) {
		initialize(name);
		frame.setVisible(true);
	}

	private void initialize(String name) {
		frame = new JFrame();
		frame.setBounds(400, 100, 472, 340);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lbl_title = new JLabel("\uC601\uD654\uAD00\uC744 \uC0AD\uC81C \uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?"); // ���⿡ name ���� ������ â�� �̸� ������
																							// �ʴ´�!!!
		lbl_title.setFont(new Font("���� ����", Font.PLAIN, 19));
		lbl_title.setBounds(108, 76, 288, 46);
		frame.getContentPane().add(lbl_title);

		JButton btnNewButton = new JButton("\uD655\uC778");
		btnNewButton.setFont(new Font("���� ����", Font.PLAIN, 13));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				DAO dao = new DAO();
				
				String cinema_name = txt_cinema_name.getText();
				//System.out.println(movie);
				
				
				int cnt = dao.deleteC(cinema_name);
				System.out.println(cnt);
				if(cnt > 0) {
					System.out.println("��ȭ������ ����");
					P04_00_Adminpage.main(null);
					frame.dispose();
				}else {
					System.out.println("��ȭ������ ����");
					txt_cinema_name.setText("");
					}
			
			}
		});
		
		btnNewButton.setBounds(122, 226, 97, 32);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1.setFont(new Font("���� ����", Font.PLAIN, 13));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_00_Adminpage.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(246, 226, 97, 32);
		frame.getContentPane().add(btnNewButton_1);

		JLabel lbl_cinema_name = new JLabel("\uC601\uD654\uAD00");
		lbl_cinema_name.setFont(new Font("���� ����", Font.BOLD, 15));
		lbl_cinema_name.setHorizontalAlignment(SwingConstants.CENTER);
		lbl_cinema_name.setBounds(39, 153, 57, 29);
		frame.getContentPane().add(lbl_cinema_name);

		txt_cinema_name = new JTextField();
		txt_cinema_name.setBounds(108, 145, 288, 46);
		frame.getContentPane().add(txt_cinema_name);
		txt_cinema_name.setColumns(10);

		JLabel lblNewLabel_1 = new JLabel("\uC601\uD654\uAD00\uC0AD\uC81C");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(59, 37, 337, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
	}
}
