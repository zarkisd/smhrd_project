import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JTextPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class infoMovie {

	private JFrame frame;
	private JTable table;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					infoMovie window = new infoMovie();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public infoMovie() {
		initialize();
	}


	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 516, 421);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(12, 10, 476, 362);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		String url = "C:\\Users\\SMHRD\\Desktop\\MovieInfo.csv";
		List<List<String>> csvlist = readFromCsv.run(url, "euc-kr");
		
		int num = 1;
		
		JLabel lbl_title = new JLabel(csvlist.get(num).get(0));
		lbl_title.setBounds(152, 27, 268, 25);
		panel.add(lbl_title);
		
		JLabel lbl_genre = new JLabel(csvlist.get(num).get(1));
		lbl_genre.setBounds(152, 62, 54, 25);
		panel.add(lbl_genre);
		
		JLabel lbl_rating = new JLabel(csvlist.get(num).get(2));
		lbl_rating.setBounds(152, 97, 17, 25);
		panel.add(lbl_rating);
		
		JLabel lbl_runtime = new JLabel(csvlist.get(num).get(3));
		lbl_runtime.setBounds(219, 97, 54, 25);
		panel.add(lbl_runtime);
		
		JLabel lbl_direc = new JLabel(csvlist.get(num).get(4));
		lbl_direc.setBounds(152, 132, 268, 25);
		panel.add(lbl_direc);
		
		JLabel lbl_actor = new JLabel(csvlist.get(num).get(5));
		lbl_actor.setBounds(152, 182, 268, 25);
		panel.add(lbl_actor);
		
		JTextPane txt_info = new JTextPane();
		txt_info.setText(csvlist.get(num).get(6));
		txt_info.setBounds(152, 226, 312, 126);
		panel.add(txt_info);

		

		
		
		
		
		
		
		
		
		
		
		
	}
}
