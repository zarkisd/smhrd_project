
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import DAO.DAO;

public class P04_02_Delete {

	private JFrame frame;
	private JTextField txt_id;
	private JTextField txt_pw;
	private static String name;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					P04_02_Delete window = new P04_02_Delete(name);
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public P04_02_Delete(String name) {
		initialize(name);
		frame.setVisible(true);
	}

	private void initialize(String name) {
		frame = new JFrame();
		frame.setBounds(400, 100, 482, 370);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lbl_name = new JLabel("\uD0C8\uD1F4 \uD558\uC2DC\uACA0\uC2B5\uB2C8\uAE4C?"); // ���⿡ name ���� ������ â�� �̸� ������
																							// �ʴ´�!!!
		lbl_name.setFont(new Font("���� ����", Font.PLAIN, 16));
		lbl_name.setBounds(158, 195, 187, 65);
		frame.getContentPane().add(lbl_name);

		JButton btnNewButton = new JButton("\uD655\uC778");

		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				DAO dao = new DAO();

				String id = txt_id.getText();
				String pw = txt_pw.getText();

				int cnt = dao.delete(id, pw);
				System.out.println(cnt);
				if (cnt > 0) {
					System.out.println("ȸ��Ż�� ����");
					P04_00_Adminpage.main(null);
					frame.dispose();
				} else {
					System.out.println("ȸ��Ż�� ����");
					txt_id.setText("");
					txt_pw.setText("");
				}

			}
		});

		btnNewButton.setBounds(83, 270, 97, 34);
		frame.getContentPane().add(btnNewButton);

		JButton btnNewButton_1 = new JButton("\uCDE8\uC18C");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				P04_00_Adminpage.main(null);

				// ���� â�� �ݱ�
				frame.dispose();
			}
		});
		btnNewButton_1.setBounds(274, 270, 97, 34);
		frame.getContentPane().add(btnNewButton_1);

		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("���� ����", Font.BOLD, 14));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(35, 95, 57, 29);
		frame.getContentPane().add(lblNewLabel);

		JLabel lblPw = new JLabel("PW");
		lblPw.setFont(new Font("���� ����", Font.BOLD, 14));
		lblPw.setHorizontalAlignment(SwingConstants.CENTER);
		lblPw.setBounds(35, 152, 57, 33);
		frame.getContentPane().add(lblPw);

		txt_id = new JTextField();
		txt_id.setBounds(104, 95, 308, 33);
		frame.getContentPane().add(txt_id);
		txt_id.setColumns(10);

		txt_pw = new JTextField();
		txt_pw.setColumns(10);
		txt_pw.setBounds(104, 151, 308, 34);
		frame.getContentPane().add(txt_pw);

		JLabel lblNewLabel_1 = new JLabel("\uD68C\uC6D0\uD0C8\uD1F4");
		lblNewLabel_1.setFont(new Font("���� ����", Font.BOLD, 16));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(75, 38, 337, 29);
		frame.getContentPane().add(lblNewLabel_1);
	}
}
